

export enum Sender {
  USER = 'user',
  BOT = 'bot'
}

export interface ChatMessage {
  id: string;
  sender: Sender;
  text: string;
  type: 'text' | 'selection' | 'preview' | 'actions' | 'join-config' | 'join-preview';
  data?: any; // For holding recommendation lists or preview data
}

// Used for AI Context & UI Display
export interface TableSchema {
  name: string;
  description: string;
  columns: string[];
  requiredWhere?: boolean;       // Added: Is WHERE clause mandatory?
  requiredWhereColumn?: string;  // Added: The specific column requiring a value
  apiId?: string;                // Added: To group tables by data source
}

export interface TableRecommendation {
  tableName: string;
  reason: string;
}

export interface PreviewData {
  tableName: string;
  columns: string[];
  rows: any[];
}

export interface JoinConfig {
  primaryTable: string;
  joins: {
    leftTable: string;
    rightTable: string;
    // Updated: Support multiple keys for composite joins
    onKeys: {
        leftColumn: string;
        rightColumn: string;
    }[];
  }[];
  selectedColumns: {
    [tableName: string]: string[]; // tableName -> array of column names
  };
  // Added: Store values for WHERE conditions
  whereConditions?: {
      [tableName: string]: {
          column: string;
          value: string;
      }
  };
}

export enum AppState {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING', // AI is thinking
  SELECTING_TABLE = 'SELECTING_TABLE', // User needs to pick a table
  PREVIEWING_DATA = 'PREVIEWING_DATA', // User is looking at data
  CONFIRMING_ACTION = 'CONFIRMING_ACTION', // Ask to continue or export
  CONFIGURING_JOIN = 'CONFIGURING_JOIN', // Configuring JOIN keys and columns
  PREVIEWING_JOIN = 'PREVIEWING_JOIN' // User confirms SQL and Joined Data
}

// --- New Configuration Types ---

export interface ApiConfig {
  id: string;
  name: string;      // API Name (API 名稱)
  path: string;      // API Path (API 路徑)
  method: 'POST' | 'GET' | 'PUT' | 'DELETE';
  bodyStructure: any; // API POST Format (API 的 POST 格式)
}

export interface TableConfig {
  tableName: string;     // Database Table Name
  displayName: string;   // Chinese Name/Label
  description: string;   // Description
  columns: string[];     // Columns
  requiredWhere: boolean; // Is WHERE clause mandatory? (是否必要 where 條件)
  requiredWhereColumn?: string; // Mandatory column for WHERE clause (if requiredWhere is true)
  apiId: string;         // Link to ApiConfig
}