
import React from 'react';
import { PreviewData } from '../types';
import { Table } from 'lucide-react';

interface Props {
  data: PreviewData;
}

const DataPreview: React.FC<Props> = ({ data }) => {
  return (
    <div className="w-full bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden mt-4 mb-6 flex flex-col max-h-[500px] animation-fade-in">
      {/* Header */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center flex-shrink-0">
        <div className="flex items-center gap-2">
            <div className="bg-indigo-100 p-1.5 rounded-lg text-indigo-600">
                <Table size={18} />
            </div>
            <div>
                <h3 className="font-bold text-slate-800">{data.tableName}</h3>
                <p className="text-xs text-slate-500">預覽前 10 筆資料</p>
            </div>
        </div>
      </div>

      {/* Table Content - Flex grow to fill space, scrollable */}
      <div className="overflow-auto flex-1 w-full bg-white scrollbar-thin scrollbar-thumb-slate-200 scrollbar-track-transparent">
        <table className="w-full text-sm text-left text-slate-600">
          <thead className="text-xs text-slate-700 uppercase bg-slate-100 sticky top-0 z-10 shadow-sm">
            <tr>
              {data.columns.map((col) => (
                <th key={col} scope="col" className="px-6 py-3 font-semibold whitespace-nowrap border-b border-slate-200 bg-slate-100">
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.map((row, idx) => (
              <tr key={idx} className="bg-white border-b hover:bg-slate-50 transition-colors last:border-b-0">
                {data.columns.map((col) => (
                  <td key={`${idx}-${col}`} className="px-6 py-3 whitespace-nowrap">
                    {row[col]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataPreview;
