

import React, { useState, useEffect } from 'react';
import { JoinConfig, TableSchema } from '../types';
import { Settings, ArrowRight, Eye, Link as LinkIcon, CheckSquare, Square, ArrowLeft, Filter, AlertCircle, CheckCircle, Plus, Trash2 } from 'lucide-react';

interface Props {
  config: JoinConfig;
  allSchemas: TableSchema[];
  onConfirm: (finalConfig: JoinConfig) => void;
  onCancel: () => void;
  onBack: () => void;
}

const JoinConfiguration: React.FC<Props> = ({ config, allSchemas, onConfirm, onCancel, onBack }) => {
  const [localConfig, setLocalConfig] = useState<JoinConfig>(config);
  const [missingRequirements, setMissingRequirements] = useState<string[]>([]);

  // Normalization Logic on Mount
  useEffect(() => {
    const normalizeConfig = (incoming: JoinConfig): JoinConfig => {
      const findRealName = (fuzzyName: string): string => {
        if (!fuzzyName) return "";
        // 1. Exact match
        const exact = allSchemas.find(t => t.name === fuzzyName);
        if (exact) return exact.name;

        // 2. Fuzzy match
        const normalize = (s: string) => s.split('(')[0].trim().toLowerCase();
        const target = normalize(fuzzyName);
        const fuzzy = allSchemas.find(t => normalize(t.name) === target || t.name.includes(fuzzyName));
        
        return fuzzy ? fuzzy.name : fuzzyName;
      };

      const newSelectedColumns: { [key: string]: string[] } = {};
      Object.keys(incoming.selectedColumns).forEach(key => {
        const realName = findRealName(key);
        newSelectedColumns[realName] = incoming.selectedColumns[key];
      });

      const newJoins = incoming.joins.map(j => {
          // Robust handling for older format or new format
          // Cast to any to handle potential mismatch during transition
          const jAny = j as any;
          const leftName = findRealName(j.leftTable);
          const rightName = findRealName(j.rightTable);
          
          let keys = j.onKeys || [];
          // Backward compatibility: If onKeys is missing but leftColumn/rightColumn exist
          if (!keys.length && jAny.leftColumn && jAny.rightColumn) {
              keys = [{ leftColumn: jAny.leftColumn, rightColumn: jAny.rightColumn }];
          }

          return {
            leftTable: leftName,
            rightTable: rightName,
            onKeys: keys
          };
      });

      // Normalize Where Conditions keys
      const newWhereConditions: any = {};
      if (incoming.whereConditions) {
          Object.keys(incoming.whereConditions).forEach(key => {
              const realName = findRealName(key);
              newWhereConditions[realName] = incoming.whereConditions![key];
          });
      }

      return {
        primaryTable: findRealName(incoming.primaryTable),
        joins: newJoins,
        selectedColumns: newSelectedColumns,
        whereConditions: newWhereConditions
      };
    };

    setLocalConfig(normalizeConfig(config));
  }, [config, allSchemas]);

  // Check validitiy whenever config changes
  useEffect(() => {
      const missing: string[] = [];
      Object.keys(localConfig.selectedColumns).forEach(tableName => {
          const schema = allSchemas.find(t => t.name === tableName);
          if (schema && schema.requiredWhere && schema.requiredWhereColumn) {
              const currentVal = localConfig.whereConditions?.[tableName]?.value;
              if (!currentVal || currentVal.trim() === '') {
                  missing.push(tableName);
              }
          }
      });
      setMissingRequirements(missing);
  }, [localConfig, allSchemas]);


  // Helper to toggle a column
  const toggleColumn = (tableName: string, col: string) => {
    const currentCols = localConfig.selectedColumns[tableName] || [];
    const newCols = currentCols.includes(col)
      ? currentCols.filter(c => c !== col)
      : [...currentCols, col];
    
    setLocalConfig({
      ...localConfig,
      selectedColumns: {
        ...localConfig.selectedColumns,
        [tableName]: newCols
      }
    });
  };
  
  const toggleAllColumns = (tableName: string, selectAll: boolean) => {
      const schema = allSchemas.find(t => t.name === tableName);
      if (!schema) return;
      
      setLocalConfig({
          ...localConfig,
          selectedColumns: {
              ...localConfig.selectedColumns,
              [tableName]: selectAll ? schema.columns : []
          }
      });
  }

  // Update a specific key inside a join definition
  const updateJoinKey = (joinIndex: number, keyIndex: number, field: 'leftColumn' | 'rightColumn', value: string) => {
      const newJoins = [...localConfig.joins];
      const newKeys = [...newJoins[joinIndex].onKeys];
      newKeys[keyIndex] = { ...newKeys[keyIndex], [field]: value };
      newJoins[joinIndex] = { ...newJoins[joinIndex], onKeys: newKeys };
      setLocalConfig({ ...localConfig, joins: newJoins });
  };

  const addJoinKey = (joinIndex: number) => {
      const newJoins = [...localConfig.joins];
      newJoins[joinIndex] = {
          ...newJoins[joinIndex],
          onKeys: [...newJoins[joinIndex].onKeys, { leftColumn: '', rightColumn: '' }]
      };
      setLocalConfig({ ...localConfig, joins: newJoins });
  };

  const removeJoinKey = (joinIndex: number, keyIndex: number) => {
      const newJoins = [...localConfig.joins];
      const newKeys = newJoins[joinIndex].onKeys.filter((_, idx) => idx !== keyIndex);
      // Ensure at least one key remains (or handle logic to remove join completely, but keeping one is safer for UI)
      if (newKeys.length === 0) {
           newKeys.push({ leftColumn: '', rightColumn: '' });
      }
      newJoins[joinIndex] = { ...newJoins[joinIndex], onKeys: newKeys };
      setLocalConfig({ ...localConfig, joins: newJoins });
  };

  const updateWhereCondition = (tableName: string, column: string, value: string) => {
      setLocalConfig({
          ...localConfig,
          whereConditions: {
              ...localConfig.whereConditions,
              [tableName]: { column, value }
          }
      });
  };

  const getColumnsForTable = (tableName: string) => {
      const schema = allSchemas.find(t => t.name === tableName);
      if (!schema) return [];
      return schema.columns;
  };

  // Identify tables that need where conditions
  const tablesWithRequiredWhere = Object.keys(localConfig.selectedColumns).filter(tableName => {
      const schema = allSchemas.find(t => t.name === tableName);
      return schema?.requiredWhere && schema?.requiredWhereColumn;
  });

  return (
    <div className="w-full bg-white border border-slate-200 rounded-xl shadow-lg mt-4 mb-6 flex flex-col animation-fade-in overflow-hidden">
      
      {/* Header */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
        <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <Settings size={18} className="text-indigo-600"/>
            資料表關聯設定 (JOIN)
        </h3>
        <span className="text-xs text-slate-500 bg-slate-200 px-2 py-1 rounded">
            AI 自動推薦設定
        </span>
      </div>

      <div className="p-6 space-y-8">
        
        {/* Section 1: Relationships */}
        <div>
            <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                <LinkIcon size={16}/> 關聯條件 (Join Keys)
            </h4>
            
            {localConfig.joins.length === 0 ? (
                <p className="text-sm text-slate-500 italic bg-slate-50 p-3 rounded">此查詢為單一資料表，無需設定 JOIN。</p>
            ) : (
                <div className="space-y-4">
                    {localConfig.joins.map((join, joinIdx) => (
                        <div key={joinIdx} className="flex flex-col gap-2 text-sm bg-slate-50 p-3 rounded-lg border border-slate-200 relative">
                             {/* Join Header info */}
                            <div className="text-xs font-semibold text-slate-400 mb-1">
                                {join.leftTable} <ArrowRight className="inline mx-1" size={10} /> {join.rightTable}
                            </div>
                            
                            {join.onKeys.map((keyPair, keyIdx) => (
                                <div key={keyIdx} className="flex flex-col md:flex-row items-center gap-2 w-full">
                                    {/* Left Side */}
                                    <div className="flex items-center gap-2 flex-1 w-full">
                                        <span className="font-semibold text-slate-700 px-2 bg-white border rounded text-ellipsis overflow-hidden whitespace-nowrap max-w-[100px] text-xs" title={join.leftTable}>
                                            {join.leftTable}
                                        </span>
                                        <select 
                                            className="flex-1 bg-white border border-slate-300 rounded px-2 py-1 text-xs"
                                            value={keyPair.leftColumn}
                                            onChange={(e) => updateJoinKey(joinIdx, keyIdx, 'leftColumn', e.target.value)}
                                        >
                                            <option value="">選擇欄位...</option>
                                            {getColumnsForTable(join.leftTable).map(c => (
                                                <option key={c} value={c}>{c}</option>
                                            ))}
                                        </select>
                                    </div>

                                    <span className="text-slate-400 font-bold">=</span>

                                    {/* Right Side */}
                                    <div className="flex items-center gap-2 flex-1 w-full">
                                        <span className="font-semibold text-slate-700 px-2 bg-white border rounded text-ellipsis overflow-hidden whitespace-nowrap max-w-[100px] text-xs" title={join.rightTable}>
                                            {join.rightTable}
                                        </span>
                                        <select 
                                            className="flex-1 bg-white border border-slate-300 rounded px-2 py-1 text-xs"
                                            value={keyPair.rightColumn}
                                            onChange={(e) => updateJoinKey(joinIdx, keyIdx, 'rightColumn', e.target.value)}
                                        >
                                            <option value="">選擇欄位...</option>
                                            {getColumnsForTable(join.rightTable).map(c => (
                                                <option key={c} value={c}>{c}</option>
                                            ))}
                                        </select>
                                    </div>

                                    {/* Remove Button (Only if more than 1 key, or clear fields) */}
                                    <button 
                                        onClick={() => removeJoinKey(joinIdx, keyIdx)}
                                        className="text-slate-400 hover:text-red-500 p-1 transition-colors"
                                        title="移除此條件"
                                        disabled={join.onKeys.length <= 1 && (!keyPair.leftColumn && !keyPair.rightColumn)}
                                    >
                                        <Trash2 size={14} />
                                    </button>
                                </div>
                            ))}
                            
                            {/* Add Condition Button */}
                            <button 
                                onClick={() => addJoinKey(joinIdx)}
                                className="self-start mt-1 flex items-center gap-1 text-[10px] text-indigo-600 hover:bg-indigo-50 px-2 py-1 rounded transition-colors"
                            >
                                <Plus size={12} />
                                增加關聯條件
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>

        {/* Section 2: Mandatory Filters (New) */}
        {tablesWithRequiredWhere.length > 0 && (
            <div>
                 <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2 text-amber-600">
                    <Filter size={16}/> 必要篩選條件 (Required Filters)
                </h4>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 space-y-4">
                     <div className="text-xs text-amber-800 mb-2 flex items-center gap-1">
                        <AlertCircle size={14} />
                        為避免查詢資料量過大，以下資料表必須設定查詢條件：
                     </div>
                     {tablesWithRequiredWhere.map(tableName => {
                         const schema = allSchemas.find(t => t.name === tableName)!;
                         const col = schema.requiredWhereColumn!;
                         const currentVal = localConfig.whereConditions?.[tableName]?.value || "";
                         const isMissing = !currentVal || currentVal.trim() === '';
                         
                         return (
                             <div key={tableName} className="flex flex-col gap-1">
                                 <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                                     <label className="text-sm font-semibold text-slate-700 w-48 truncate" title={tableName}>
                                         {tableName}
                                         <span className="block text-[10px] text-slate-500 font-normal">指定欄位: {col}</span>
                                     </label>
                                     
                                     <div className="flex-1 relative">
                                        <input 
                                            type="text"
                                            value={currentVal}
                                            onChange={(e) => updateWhereCondition(tableName, col, e.target.value)}
                                            placeholder={`例如: 2023-01-01 或 ORD-1001`}
                                            className={`w-full text-sm border px-3 py-2 pr-8 rounded transition-all outline-none ${
                                                isMissing 
                                                ? 'border-red-400 bg-red-50 focus:ring-2 focus:ring-red-200 placeholder:text-red-300' 
                                                : 'border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white'
                                            }`}
                                        />
                                        {isMissing ? (
                                            <AlertCircle size={16} className="absolute right-2 top-1/2 -translate-y-1/2 text-red-500 animate-pulse" />
                                        ) : (
                                            <CheckCircle size={16} className="absolute right-2 top-1/2 -translate-y-1/2 text-green-500" />
                                        )}
                                     </div>
                                 </div>
                                 {isMissing && (
                                     <div className="sm:ml-48 text-[11px] text-red-500 font-bold flex items-center gap-1">
                                         * 此為必填欄位，請輸入篩選條件
                                     </div>
                                 )}
                             </div>
                         );
                     })}
                </div>
            </div>
        )}

        {/* Section 3: Columns */}
        <div>
            <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                <CheckSquare size={16}/> 輸出欄位 (Output Columns)
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.keys(localConfig.selectedColumns).map(tableName => {
                    const columns = getColumnsForTable(tableName);
                    if (columns.length === 0) return null;

                    return (
                        <div key={tableName} className="border border-slate-200 rounded-lg p-3 flex flex-col">
                            <div className="flex justify-between items-center border-b pb-2 mb-2">
                                <div className="font-semibold text-xs text-slate-700 truncate" title={tableName}>
                                    {tableName}
                                </div>
                                <div className="flex gap-2">
                                    <button 
                                        onClick={() => toggleAllColumns(tableName, true)}
                                        className="text-[10px] text-indigo-600 hover:bg-indigo-50 px-1.5 py-0.5 rounded"
                                    >
                                        全選
                                    </button>
                                    <button 
                                        onClick={() => toggleAllColumns(tableName, false)}
                                        className="text-[10px] text-slate-400 hover:bg-slate-100 px-1.5 py-0.5 rounded"
                                    >
                                        清除
                                    </button>
                                </div>
                            </div>
                            <div className="space-y-1 overflow-y-auto max-h-[150px] scrollbar-thin scrollbar-thumb-slate-200">
                                {columns.map(col => {
                                    const isChecked = localConfig.selectedColumns[tableName]?.includes(col);
                                    return (
                                        <button 
                                            key={col}
                                            onClick={() => toggleColumn(tableName, col)}
                                            className="flex items-center gap-2 text-sm w-full hover:bg-slate-50 p-1 rounded transition-colors group"
                                        >
                                            {isChecked 
                                                ? <CheckSquare size={16} className="text-indigo-600 flex-shrink-0" /> 
                                                : <Square size={16} className="text-slate-300 group-hover:text-slate-400 flex-shrink-0" />
                                            }
                                            <span className={`truncate text-xs ${isChecked ? 'text-slate-800' : 'text-slate-400'}`}>{col}</span>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>

      </div>

      {/* Footer Actions */}
      <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
        <button 
            onClick={onCancel}
            className="px-4 py-2 text-slate-500 hover:text-red-600 text-sm font-medium hover:bg-red-50 rounded-lg transition-colors"
        >
            取消操作
        </button>
        <div className="flex gap-3">
            <button 
                onClick={onBack}
                className="flex items-center gap-2 px-4 py-2 text-slate-600 bg-white border border-slate-300 hover:bg-slate-50 text-sm font-medium rounded-lg transition-colors shadow-sm"
            >
                <ArrowLeft size={16} />
                返回上一頁
            </button>
            <button 
                onClick={() => onConfirm(localConfig)}
                disabled={missingRequirements.length > 0}
                className={`flex items-center gap-2 px-5 py-2 text-white text-sm font-bold rounded-lg shadow-sm transition-all active:scale-[0.98] ${
                    missingRequirements.length > 0 
                    ? 'bg-slate-400 cursor-not-allowed' 
                    : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
                title={missingRequirements.length > 0 ? `請填寫必要條件: ${missingRequirements.join(', ')}` : ""}
            >
                <Eye size={16} />
                確認並預覽結果
            </button>
        </div>
      </div>
    </div>
  );
};

export default JoinConfiguration;