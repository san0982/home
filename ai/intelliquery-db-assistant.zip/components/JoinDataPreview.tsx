
import React from 'react';
import { Download, ArrowLeft, Database, Code } from 'lucide-react';

interface Props {
  sql: string;
  data: any[];
  columns: string[];
  onBack: () => void;
  onExport: () => void;
}

const JoinDataPreview: React.FC<Props> = ({ sql, data, columns, onBack, onExport }) => {
  return (
    <div className="w-full bg-white border border-slate-200 rounded-xl shadow-lg flex flex-col mt-4 mb-6 animation-fade-in overflow-hidden">
      
      {/* Header */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
        <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <Database size={18} className="text-indigo-600"/>
            查詢結果預覽 (SQL Preview)
        </h3>
      </div>

      <div className="flex flex-col max-h-[600px] overflow-hidden">
          
          {/* SQL Viewer */}
          <div className="bg-slate-900 p-4 overflow-x-auto border-b border-slate-200 flex-shrink-0">
             <div className="flex items-center gap-2 text-slate-400 text-xs mb-2 font-bold uppercase tracking-wider">
                <Code size={14} /> Generated SQL
             </div>
             <pre className="text-slate-50 font-mono text-sm leading-relaxed whitespace-pre-wrap">
                {sql}
             </pre>
          </div>

          {/* Table Preview */}
          <div className="overflow-auto flex-1 bg-white scrollbar-thin scrollbar-thumb-slate-200 scrollbar-track-transparent">
             {data.length === 0 ? (
                 <div className="p-8 text-center text-slate-500">
                     無符合資料
                 </div>
             ) : (
                <table className="w-full text-sm text-left text-slate-600">
                <thead className="text-xs text-slate-700 uppercase bg-slate-100 sticky top-0 z-10 shadow-sm">
                    <tr>
                    {columns.map((col) => (
                        <th key={col} scope="col" className="px-6 py-3 font-semibold whitespace-nowrap border-b border-slate-200 bg-slate-100">
                        {col}
                        </th>
                    ))}
                    </tr>
                </thead>
                <tbody>
                    {data.map((row, idx) => (
                    <tr key={idx} className="bg-white border-b hover:bg-slate-50 transition-colors last:border-b-0">
                        {columns.map((col) => (
                        <td key={`${idx}-${col}`} className="px-6 py-3 whitespace-nowrap">
                            {row[col]}
                        </td>
                        ))}
                    </tr>
                    ))}
                </tbody>
                </table>
             )}
          </div>
      </div>

      {/* Footer Actions */}
      <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-3">
        <button 
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 text-slate-600 bg-white border border-slate-300 hover:bg-slate-50 text-sm font-medium rounded-lg transition-colors shadow-sm"
        >
            <ArrowLeft size={16} />
            返回設定
        </button>
        <button 
            onClick={onExport}
            className="flex items-center gap-2 px-5 py-2 bg-green-600 text-white text-sm font-bold rounded-lg shadow-sm hover:bg-green-700 transition-all active:scale-[0.98]"
        >
            <Download size={16} />
            確認無誤，匯出 Excel
        </button>
      </div>
    </div>
  );
};

export default JoinDataPreview;
