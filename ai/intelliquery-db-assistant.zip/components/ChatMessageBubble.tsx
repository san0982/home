import React from 'react';
import { ChatMessage, Sender } from '../types';
import { Bot, User } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface Props {
  message: ChatMessage;
}

const ChatMessageBubble: React.FC<Props> = ({ message }) => {
  const isBot = message.sender === Sender.BOT;

  return (
    <div className={`flex w-full mb-4 ${isBot ? 'justify-start' : 'justify-end'}`}>
      <div className={`flex max-w-[85%] md:max-w-[70%] ${isBot ? 'flex-row' : 'flex-row-reverse'} gap-3`}>
        {/* Avatar */}
        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${isBot ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-200 text-slate-600'}`}>
          {isBot ? <Bot size={18} /> : <User size={18} />}
        </div>

        {/* Bubble */}
        <div className={`p-4 rounded-2xl text-sm leading-relaxed shadow-sm ${
          isBot 
            ? 'bg-white border border-slate-100 text-slate-800 rounded-tl-none' 
            : 'bg-indigo-600 text-white rounded-tr-none'
        }`}>
          {message.type === 'text' && (
             <div className="prose prose-sm max-w-none prose-p:my-0 prose-headings:my-1 prose-ul:my-1 text-inherit dark:prose-invert">
                <ReactMarkdown>{message.text}</ReactMarkdown>
             </div>
          )}
          {message.type !== 'text' && (
             <p>{message.text}</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatMessageBubble;
