
# IntelliQuery DB Assistant - 專案文件說明

本文件詳細說明專案中各個檔案的功能與用途，協助開發者快速理解系統架構。

## 核心入口與設定 (Root)

- **`index.html`**
  - 專案的 HTML 入口文件。
  - 負責引入 Tailwind CSS (CDN)、Google Fonts (Noto Sans TC) 以及 React 相關的依賴庫 (透過 importmap)。

- **`index.tsx`**
  - React 應用程式的進入點 (Entry Point)。
  - 負責將 `<App />` 元件掛載到 DOM (`#root`) 上。

- **`metadata.json`**
  - 定義應用程式的基本資訊，如名稱、描述以及權限請求 (目前無特殊權限)。

- **`types.ts`**
  - TypeScript 型別定義檔。
  - 定義全域共用的介面 (Interfaces) 與列舉 (Enums)，包括：
    - `AppState`: 應用程式的狀態機定義。
    - `TableConfig` / `ApiConfig`: 設定檔結構。
    - `JoinConfig`: 資料表關聯設定結構。
    - `ChatMessage`: 聊天訊息格式。

## 核心邏輯 (Core Component)

- **`App.tsx`**
  - 應用程式的主控制器 (Main Container)。
  - 管理全域狀態 (`appState`)，控制目前的畫面流程 (閒置、選表、預覽、設定關聯、匯出)。
  - 處理側邊欄 (Sidebar) 與主畫面 (Main Area) 的佈局。
  - 協調 API 呼叫、資料流動以及元件之間的互動。

## 服務層 (Services)

- **`services/schemaConfig.ts`**
  - **系統設定核心**。包含所有的靜態 JSON 設定資料。
  - `API_CONFIGS`: 定義 API 的名稱、路徑與 POST 格式。
  - `TABLE_CONFIGS`: 定義資料表名稱 (英文/中文)、欄位、描述以及是否需要 WHERE 條件。

- **`services/mockDb.ts`**
  - **模擬資料庫層**。
  - 根據 `schemaConfig.ts` 的設定動態生成模擬數據 (Mock Data)。
  - `getMockData`: 取得單一資料表的假資料。
  - `getJoinableData`: 在前端模擬 SQL JOIN 的邏輯，根據使用者設定的 Key 將多張表的假資料合併。

- **`services/geminiService.ts`**
  - **AI 整合層**。負責與 Google Gemini API 溝通。
  - `generateContentWithRetry`: 包含指數退避 (Exponential Backoff) 的 API 重試機制。
  - `getTableRecommendations`: 分析使用者語意，推薦相關資料表。
  - `suggestJoinConfiguration`: 分析多張資料表，自動推薦 JOIN Key 與輸出欄位。
  - `generateNaturalResponse`: 處理一般閒聊回應。

- **`services/config.ts`**
  - *(已棄用)* 舊的設定檔入口，目前僅保留指向 `schemaConfig.ts` 的引用以維持相容性。

## 元件層 (Components)

- **`components/ChatMessageBubble.tsx`**
  - 聊天訊息氣泡元件。
  - 負責渲染使用者 (User) 與機器人 (Bot) 的對話內容，支援 Markdown 格式。

- **`components/TableSelection.tsx`**
  - **流程步驟：選擇資料表**。
  - 顯示 AI 推薦的資料表卡片。
  - 處理使用者的選取、取消與已選取狀態的視覺回饋。

- **`components/DataPreview.tsx`**
  - **流程步驟：單一資料表預覽**。
  - 當使用者點擊單一資料表時，顯示前 10 筆預覽資料。
  - 包含「確認選取」與「返回」的功能按鈕 (按鈕實際渲染位置可能由 App.tsx 控制)。

- **`components/JoinConfiguration.tsx`**
  - **流程步驟：設定關聯 (JOIN)**。
  - 提供介面讓使用者設定：
    - 關聯鍵 (Left Table.Column = Right Table.Column)。
    - 輸出欄位 (勾選要顯示的 Columns)。
  - 支援全選/清除欄位以及返回上一頁。

- **`components/JoinDataPreview.tsx`**
  - **流程步驟：最終預覽與匯出**。
  - 顯示產生的 SQL 語法 (Generated SQL)。
  - 顯示合併後的資料表預覽 (Result Table)。
  - 提供「匯出 Excel」與「返回設定」的功能。

---

## 安裝與執行手冊 (Installation Guide)

本專案使用 React 19 與 TypeScript 開發，並整合 Google Gemini API。請依照以下步驟在本地端建立開發環境。

### 1. 系統需求 (Prerequisites)
- **Node.js**: 建議版本 v18 或更高 (需支援 ESM)。
- **套件管理器**: npm 或 yarn。
- **Google API Key**: 需擁有 Gemini API 的存取權限。

### 2. 安裝步驟 (Installation Steps)

1.  **取得專案程式碼**
    將專案檔案下載至本地端目錄。

2.  **安裝相依套件**
    開啟終端機 (Terminal)，進入專案根目錄並執行：
    ```bash
    npm install
    ```
    *(若使用 yarn 則執行 `yarn install`)*

3.  **設定環境變數 (Environment Setup)**
    本專案需要 Google Gemini API Key 才能運作。
    
    - 前往 [Google AI Studio](https://aistudio.google.com/) 申請 API Key。
    - 若您使用 bundler (如 Vite/Webpack) 運行，請確保環境變數能被正確注入。
    - 若在支援 `process.env` 的環境下，請建立 `.env` 檔案：
      ```env
      API_KEY=您的_GOOGLE_GEMINI_API_KEY
      ```
    *(注意：`services/geminiService.ts` 內預設使用 `process.env.API_KEY`，請依據您的執行環境調整讀取方式)*

### 3. 啟動開發伺服器 (Running the App)

執行以下指令啟動本地開發伺服器：

```bash
npm run start
# 或
npm run dev
```

啟動後，請打開瀏覽器訪問 (通常為 `http://localhost:3000` 或 `http://localhost:5173`) 即可開始使用。

### 4. 建置生產版本 (Build for Production)

若需部署至正式環境，請執行：

```bash
npm run build
```

這將會在 `dist` 或 `build` 資料夾中產生最佳化後的靜態檔案。

---

## 架構遷移指引 (Backend Migration)

目前專案為純前端演示 (Demo)，**API Key 與 Gemini SDK 邏輯皆位於前端** (`services/geminiService.ts`)。若要將此專案部署至生產環境，強烈建議將 AI 邏輯移至後端伺服器以保護 API Key。

以下是遷移所需的修改步驟：

### 1. 前端修改 (Frontend Changes)
你需要修改 `services/geminiService.ts`，使其不再直接呼叫 Gemini SDK，而是呼叫你的後端 API。

*   **移除依賴**: 刪除 `import { GoogleGenAI } ...` 相關程式碼。
*   **移除 Key**: 刪除 `process.env.API_KEY` 的引用。
*   **修改函式**: 將 `getTableRecommendations` 與 `suggestJoinConfiguration` 改寫為 `fetch()` 呼叫。
    *   例如：`fetch('/api/ai/recommend-tables', { method: 'POST', body: JSON.stringify({ query: userQuery }) })`

### 2. 後端實作 (Backend Implementation)
你需要建立一個後端服務 (如 Node.js/Express, Python/FastAPI, Go 等)。

*   **環境變數**: 將 `API_KEY` 移至後端伺服器的環境變數中，確保不外洩。
*   **安裝 SDK**: 在後端專案中安裝 `@google/genai` (Node.js) 或 `google-genai` (Python)。
*   **搬移邏輯**:
    *   將 `services/geminiService.ts` 內的 Prompt (提示詞) 與 `systemInstruction` 邏輯複製到後端。
    *   建立對應的 API Endpoints (例如 `/api/ai/recommend-tables`)。
    *   後端接收前端傳來的 `userQuery` 與 `schema` (或是由後端直接讀取 DB Schema)，呼叫 Gemini API，並將結果回傳給前端。

### 3. 安全性增強 (Security)
*   後端可以實作 Rate Limiting (速率限制) 以防止 API 被濫用。
*   可以加入使用者驗證 (Authentication)，確保只有授權用戶能觸發 AI 分析。
