import React, { useState, useEffect, useRef } from 'react';
import { Send, FileSpreadsheet, Plus, X, Sparkles, Loader2, ArrowLeft, Check, Database, ArrowRight, Code, Server, Play, Trash2, AlertTriangle, Info } from 'lucide-react';
import * as XLSX from 'xlsx';

import { AppState, ChatMessage, Sender, TableRecommendation, PreviewData, JoinConfig } from './types';
import { DB_SCHEMA, fetchTableData, fetchJoinData, setMockMode, getApiPreviewForTable, resolveTableConfig } from './services/mockDb';
import { getTableRecommendations, generateNaturalResponse, suggestJoinConfiguration } from './services/geminiService';

import ChatMessageBubble from './components/ChatMessageBubble';
import TableSelection from './components/TableSelection';
import DataPreview from './components/DataPreview';
import JoinConfiguration from './components/JoinConfiguration';
import JoinDataPreview from './components/JoinDataPreview';

// --- SKELETON COMPONENTS ---

const SkeletonTable = ({ hasSql = false }: { hasSql?: boolean }) => (
  <div className="w-full bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden mt-4 mb-6 flex flex-col h-[500px] animate-pulse">
    {/* Header */}
    <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center gap-3">
        <div className="w-8 h-8 bg-slate-200 rounded-lg"></div>
        <div className="h-4 w-32 bg-slate-200 rounded"></div>
    </div>
    
    {/* SQL Placeholder */}
    {hasSql && (
        <div className="bg-slate-900 p-4 border-b border-slate-200 h-24 flex flex-col justify-center space-y-2">
            <div className="h-3 bg-slate-700 rounded w-1/4"></div>
            <div className="h-3 bg-slate-700 rounded w-3/4"></div>
            <div className="h-3 bg-slate-700 rounded w-1/2"></div>
        </div>
    )}

    {/* Content */}
    <div className="flex-1 flex flex-col">
        {/* Table Header */}
        <div className="bg-slate-100 p-3 flex gap-4 border-b border-slate-200">
             {[1,2,3,4,5].map(i => <div key={i} className="h-4 bg-slate-200 rounded w-24"></div>)}
        </div>
        {/* Rows */}
        <div className="flex-1 p-0">
             {[...Array(8)].map((_, i) => (
                 <div key={i} className="p-4 border-b border-slate-100 flex gap-4">
                    {[...Array(5)].map((_, j) => <div key={j} className="h-3 bg-slate-50 rounded w-24"></div>)}
                 </div>
             ))}
        </div>
    </div>
  </div>
);

const SkeletonJoinConfig = () => (
  <div className="w-full bg-white border border-slate-200 rounded-xl shadow-lg mt-4 mb-6 flex flex-col animate-pulse overflow-hidden">
      {/* Header */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center gap-3">
        <div className="w-6 h-6 bg-slate-200 rounded"></div>
        <div className="h-5 w-48 bg-slate-200 rounded"></div>
      </div>

      <div className="p-6 space-y-8">
          {/* Section 1 */}
          <div>
              <div className="h-4 w-32 bg-slate-200 rounded mb-3"></div>
              <div className="space-y-3">
                   <div className="h-12 bg-slate-50 rounded-lg border border-slate-100 w-full"></div>
                   <div className="h-12 bg-slate-50 rounded-lg border border-slate-100 w-full"></div>
              </div>
          </div>
          
          {/* Section 2 */}
          <div>
              <div className="h-4 w-32 bg-slate-200 rounded mb-3"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="h-40 bg-slate-50 rounded-lg border border-slate-100"></div>
                  <div className="h-40 bg-slate-50 rounded-lg border border-slate-100"></div>
              </div>
          </div>
      </div>
      
      {/* Footer */}
      <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between">
          <div className="h-9 w-24 bg-slate-200 rounded-lg"></div>
          <div className="flex gap-3">
             <div className="h-9 w-24 bg-slate-200 rounded-lg"></div>
             <div className="h-9 w-32 bg-slate-300 rounded-lg"></div>
          </div>
      </div>
  </div>
);

interface AlertState {
    isOpen: boolean;
    title: string;
    message: string;
    type: 'warning' | 'error' | 'info';
}

// --- MAIN APP ---

export default function App() {
  // State
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: Sender.BOT,
      text: '你好！我是你的智慧資料庫助手。請在左側輸入你想查詢的內容。(例如：「我想查看最近的訂單」)',
      type: 'text'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [isLoading, setIsLoading] = useState(false); // New Loading State
  
  const [selectedTableNames, setSelectedTableNames] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState<TableRecommendation[]>([]);
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  
  // Join Config State
  const [currentJoinConfig, setCurrentJoinConfig] = useState<JoinConfig | null>(null);
  const [originalUserQuery, setOriginalUserQuery] = useState('');
  
  // Join Preview State
  const [previewJoinRows, setPreviewJoinRows] = useState<any[]>([]);
  const [previewJoinColumns, setPreviewJoinColumns] = useState<string[]>([]);
  const [generatedSql, setGeneratedSql] = useState<string>("");
  
  // Configuration State
  const [isMockMode, setIsMockMode] = useState(true);

  // API Execution Modal State
  const [apiPreviewModal, setApiPreviewModal] = useState<{
      visible: boolean;
      data: any;
  }>({ visible: false, data: null });

  // Alert Modal State
  const [alertState, setAlertState] = useState<AlertState>({
      isOpen: false,
      title: '',
      message: '',
      type: 'info'
  });

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Sync Mock Mode with Service on mount and when state changes
  useEffect(() => {
    setMockMode(isMockMode);
  }, [isMockMode]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, appState, currentJoinConfig, previewJoinRows, isLoading]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [inputText]);

  // Handlers
  const handleToggleMockMode = () => {
    const newVal = !isMockMode;
    setIsMockMode(newVal);
    // setMockMode is also called by useEffect, but direct call ensures immediate update logic if needed
    setMockMode(newVal);
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;
    if (appState !== AppState.IDLE && appState !== AppState.CONFIRMING_ACTION) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: Sender.USER,
      text: inputText,
      type: 'text'
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setOriginalUserQuery(inputText); // Save for later context
    
    // Capture the current state (IDLE or CONFIRMING_ACTION) to restore it later if needed
    const previousState = appState;
    setAppState(AppState.ANALYZING);

    // AI Processing
    try {
        // Step 1: Analyze user intent to get table recommendations
        // Pass selectedTableNames to enforce API ID filtering
        const recs = await getTableRecommendations(userMsg.text, DB_SCHEMA, selectedTableNames);
        
        if (recs.length > 0) {
            setRecommendations(recs);
            const botMsg: ChatMessage = {
                id: (Date.now() + 1).toString(),
                sender: Sender.BOT,
                text: `收到，根據你的需求「${userMsg.text}」，我找到了以下相關的資料表。請點擊選擇：`,
                type: 'text'
            };
            setMessages(prev => [...prev, botMsg]);
            setAppState(AppState.SELECTING_TABLE);
        } else {
             // Fallback chat if no tables found
             const replyText = await generateNaturalResponse(userMsg.text);
             
             // Removed verbose filtering warning to satisfy user request ("don't explain too much")
             
            setMessages(prev => [...prev, {
                id: (Date.now() + 1).toString(),
                sender: Sender.BOT,
                text: replyText,
                type: 'text'
            }]);
            
            // Restore the previous state (IDLE or CONFIRMING_ACTION)
            // This ensures the "AI Processing" indicator is removed
            setAppState(previousState);
        }
    } catch (error: any) {
        console.error("Analysis Error:", error);
        
        let errorText = "抱歉，分析時發生錯誤，請稍後再試。";
        const status = error?.status || error?.response?.status || error?.error?.code;

        if (status === 429) {
            errorText = "⚠️ 系統目前使用量已達上限 (Quota Exceeded)，暫時無法進行分析，請稍後再試。";
        }

        setMessages(prev => [...prev, {
            id: (Date.now() + 1).toString(),
            sender: Sender.BOT,
            text: errorText,
            type: 'text'
        }]);
        
        // Restore previous state on error
        setAppState(previousState);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
    }
  };

  const handleTableSelect = async (tableName: string) => {
    // Intercept in API Mode to show preview
    if (!isMockMode) {
        try {
            const preview = getApiPreviewForTable(tableName);
            setApiPreviewModal({ visible: true, data: preview });
        } catch (e) {
            console.error("Failed to prepare API request", e);
            // Fallback to error message
             setMessages(prev => [...prev, {
                id: Date.now().toString(),
                sender: Sender.BOT,
                text: `準備 API 請求失敗：${(e as Error).message}`,
                type: 'text'
            }]);
        }
        return;
    }

    // Standard Mock Execution
    performFetchTableData(tableName);
  };

  const handleExecuteApi = () => {
      if (apiPreviewModal.data && apiPreviewModal.data.tableName) {
          performFetchTableData(apiPreviewModal.data.tableName);
          setApiPreviewModal({ visible: false, data: null });
      }
  };

  const performFetchTableData = async (tableName: string) => {
    setIsLoading(true);
    setAppState(AppState.PREVIEWING_DATA); // Switch visual state early, but show loading
    try {
        const data = await fetchTableData(tableName);
        setPreviewData(data);
        
        // Alert Logic for API Mode
        if (!isMockMode) {
            // 1. Check if rows are empty
            if (data.rows.length === 0) {
                 setAlertState({
                     isOpen: true,
                     title: '查無資料 (No Data)',
                     message: 'API 請求成功，但回傳的資料集為空。請確認 API 參數或資料庫狀態。',
                     type: 'warning'
                 });
            } else {
                // 2. Check Schema Mismatch
                // Find original config to compare expected columns
                const originalConfig = DB_SCHEMA.find(t => t.name === data.tableName);
                if (originalConfig) {
                    const expectedCols = originalConfig.columns.join(',');
                    const actualCols = data.columns.join(',');
                    
                    if (expectedCols !== actualCols) {
                        setAlertState({
                            isOpen: true,
                            title: '欄位不符 (Schema Mismatch)',
                            message: `注意：API 回傳的欄位與系統設定不符。\n\n預期欄位: [${originalConfig.columns.slice(0,3).join(', ')}...]\n實際欄位: [${data.columns.slice(0,3).join(', ')}...]\n\n系統已自動調整顯示內容。`,
                            type: 'warning'
                        });
                    }
                }
            }
        }

    } catch (e: any) {
        console.error(e);
        let errorMsg = `抱歉，讀取資料表 "${tableName}" 失敗。`;
        if (e.message) errorMsg += `\n錯誤訊息: ${e.message}`;

        setMessages(prev => [...prev, {
            id: Date.now().toString(),
            sender: Sender.BOT,
            text: errorMsg,
            type: 'text'
        }]);
        setAppState(AppState.SELECTING_TABLE); // Go back
    } finally {
        setIsLoading(false);
    }
  };

  const handleCancelSelection = () => {
      setAppState(AppState.IDLE);
      setCurrentJoinConfig(null);
      setPreviewData(null);
      setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: Sender.BOT,
          text: "已取消操作。請問還有什麼可以幫您的？",
          type: 'text'
      }]);
  };

  const handleBackToSelection = () => {
      setAppState(AppState.SELECTING_TABLE);
      setPreviewData(null);
  };

  const handleConfirmTable = () => {
      if (!previewData) return;
      
      // --- VALIDATION START ---
      // Prevent selecting tables with different API IDs
      if (selectedTableNames.length > 0) {
          const firstTable = selectedTableNames[0];
          const firstConfig = resolveTableConfig(firstTable);
          const currentConfig = resolveTableConfig(previewData.tableName);
          
          if (firstConfig && currentConfig && firstConfig.apiId !== currentConfig.apiId) {
             setAlertState({
                 isOpen: true,
                 title: '無法選取此資料表 (Incompatible Data Source)',
                 message: `您已選取來源為 [${firstConfig.apiId}] 的資料表，但此資料表來源為 [${currentConfig.apiId}]。\n\n系統不支援跨 API 來源的 JOIN 操作，無法加入此資料表。`,
                 type: 'error'
             });
             return;
          }
      }
      // --- VALIDATION END ---

      const newSelected = [...selectedTableNames, previewData.tableName];
      setSelectedTableNames(newSelected);
      setPreviewData(null);
      setAppState(AppState.CONFIRMING_ACTION);
      
      setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: Sender.BOT,
          text: `已加入 **${previewData.tableName}**。\n\n請問您要繼續選取其他資料表，還是進行下一步？`,
          type: 'text'
      }]);
  };

  const handleRemoveSelectedTable = (name: string) => {
      setSelectedTableNames(prev => prev.filter(t => t !== name));
      // If we remove all tables while in a configuration/preview state, we might need to reset state, 
      // but for now keeping it simple or let the user decide.
      if (selectedTableNames.length <= 1 && (appState === AppState.CONFIGURING_JOIN || appState === AppState.PREVIEWING_JOIN)) {
         setAppState(AppState.IDLE);
         setCurrentJoinConfig(null);
         setPreviewJoinRows([]);
         setMessages(prev => [...prev, {
            id: Date.now().toString(),
            sender: Sender.BOT,
            text: "因已無選取資料表，操作已重置。",
            type: 'text'
         }]);
      }
  };

  const handleClearAllTables = () => {
      setSelectedTableNames([]);
      setAppState(AppState.IDLE);
      setCurrentJoinConfig(null);
      setPreviewData(null);
      setPreviewJoinRows([]);
      setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: Sender.BOT,
          text: "已清除所有選取的資料表。",
          type: 'text'
      }]);
  };

  const handleContinueSelection = () => {
      setAppState(AppState.IDLE);
      setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: Sender.BOT,
          text: "好的，請告訴我下一個你想關聯或查詢的資料表條件。",
          type: 'text'
      }]);
  };

  // Triggered by "Next Step"
  const handleProceedToConfiguration = async () => {
      if (selectedTableNames.length === 0) return;

      // --- VALIDATION START ---
      // Check if all selected tables belong to the same API ID (Source)
      if (selectedTableNames.length > 1) {
          const firstConfig = resolveTableConfig(selectedTableNames[0]);
          const baseApiId = firstConfig?.apiId;
          const hasMixedSources = selectedTableNames.some(t => {
              const cfg = resolveTableConfig(t);
              return cfg?.apiId !== baseApiId;
          });

          if (hasMixedSources) {
              setAlertState({
                  isOpen: true,
                  title: '不支援跨來源關聯 (Cross-Source Join)',
                  message: '您選取的資料表來自不同的 API 來源。目前系統僅支援相同 API 來源的資料表進行 JOIN。\n\n請移除不相容的資料表後再試一次。',
                  type: 'error'
              });
              return;
          }
      }
      // --- VALIDATION END ---

      // Switch to Configuration State immediately with Loading
      setAppState(AppState.CONFIGURING_JOIN);
      setIsLoading(true);
      setCurrentJoinConfig(null); // Ensure null so we don't render old config

      setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: Sender.BOT,
          text: "正在分析資料表關聯性與推薦欄位...",
          type: 'text'
      }]);

      try {
          const config = await suggestJoinConfiguration(selectedTableNames, DB_SCHEMA, originalUserQuery);
          
          if (config) {
              setCurrentJoinConfig(config);
              setMessages(prev => [...prev, {
                  id: Date.now().toString(),
                  sender: Sender.BOT,
                  text: "我已為您產生推薦的關聯設定與欄位。請確認或修改設定：",
                  type: 'text'
              }]);
          } else {
             // Fallback if AI fails
             const fallbackConfig: JoinConfig = {
                 primaryTable: selectedTableNames[0],
                 joins: [], 
                 selectedColumns: selectedTableNames.reduce((acc, curr) => {
                     const schema = DB_SCHEMA.find(t => t.name === curr);
                     acc[curr] = schema ? schema.columns : [];
                     return acc;
                 }, {} as {[key: string]: string[]})
             };
             setCurrentJoinConfig(fallbackConfig);
          }

      } catch (e: any) {
          console.error(e);
          // Handle Error in Join Step
          const status = e?.status || e?.response?.status || e?.error?.code;
          let msg = "抱歉，分析時發生錯誤。";
          if (status === 429) {
              msg = "⚠️ 系統使用量已達上限 (Quota Exceeded)，暫時無法分析關聯，請稍後再試。";
          }
          
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            sender: Sender.BOT,
            text: msg,
            type: 'text'
         }]);

          setAppState(AppState.CONFIRMING_ACTION); 
      } finally {
          setIsLoading(false);
      }
  };
  
  const handleBackToConfirmation = () => {
    setAppState(AppState.CONFIRMING_ACTION);
    setCurrentJoinConfig(null);
  };

  // Simple SQL Generator
  const generateSQL = (config: JoinConfig): string => {
      const selects: string[] = [];
      Object.entries(config.selectedColumns).forEach(([table, cols]) => {
          // Naive table alias logic: use table name directly, but add explicit alias to avoid ambiguity
          cols.forEach(col => selects.push(`${table}.${col} AS "${table}.${col}"`));
      });

      let sql = `SELECT\n  ${selects.length > 0 ? selects.join(',\n  ') : '*'}\nFROM ${config.primaryTable}`;

      config.joins.forEach(join => {
          // Handle Multiple Join Keys
          const onClauses = join.onKeys.map(key => 
              `${join.leftTable}.${key.leftColumn} = ${join.rightTable}.${key.rightColumn}`
          ).join(' AND ');

          if (onClauses) {
             sql += `\nLEFT JOIN ${join.rightTable} ON ${onClauses}`;
          } else {
             // Fallback for safety
             sql += `\nLEFT JOIN ${join.rightTable} ON 1=1`;
          }
      });

      let hasWhere = false;

      // 1. Check Primary Table Requirement
      const primaryTableConfig = resolveTableConfig(config.primaryTable);
      const isPrimaryRequired = primaryTableConfig && primaryTableConfig.requiredWhere;

      if (isPrimaryRequired) {
          const val = config.whereConditions?.[config.primaryTable]?.value;
          // Note: UI enforces input validation, but we check here too
          if (val) {
              const col = primaryTableConfig?.requiredWhereColumn || 'Column';
              sql += `\nWHERE ${config.primaryTable}.${col} = '${val}'`;
              hasWhere = true;
          }
      }
      
      // 2. Check Other Tables (and the primary one if it had a condition but wasn't mandatory)
      if (config.whereConditions) {
          Object.keys(config.whereConditions).forEach(tableName => {
              // Skip if we already handled this table as the primary required table
              if (isPrimaryRequired && tableName === config.primaryTable) {
                  return;
              }

              const cond = config.whereConditions![tableName];
              if (cond && cond.value) {
                  const prefix = hasWhere ? 'AND' : 'WHERE';
                  sql += `\n${prefix} ${tableName}.${cond.column} = '${cond.value}'`;
                  hasWhere = true;
              }
          });
      }

      return sql;
  };

  const handleShowJoinPreview = async (config: JoinConfig) => {
      // 1. Generate SQL
      const sql = generateSQL(config);
      setGeneratedSql(sql);
      setCurrentJoinConfig(config); // Update local config with latest user edits
      
      setIsLoading(true);
      setAppState(AppState.PREVIEWING_JOIN);

      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        sender: Sender.BOT,
        text: "正在執行查詢並產生預覽...",
        type: 'text'
      }]);

      try {
          // 2. Fetch Data Preview (Join) - Async
          const joinedData = await fetchJoinData(
            selectedTableNames, 
            config,
            sql
          );

          setPreviewJoinRows(joinedData);
          
          // Extract columns from first row, or from config if empty
          const cols = joinedData.length > 0 ? Object.keys(joinedData[0]) : [];
          setPreviewJoinColumns(cols);

          setMessages(prev => {
              const msgs = [...prev];
              msgs.pop(); // Remove loading msg
              return [...msgs, {
                id: Date.now().toString(),
                sender: Sender.BOT,
                text: "這是您的查詢結果預覽與 SQL 語法。請確認無誤後匯出。",
                type: 'text'
              }];
          });
          
          // Check for empty data logic (API Mode)
          if (!isMockMode && joinedData.length === 0) {
             setAlertState({
                 isOpen: true,
                 title: '查無資料 (No Data)',
                 message: '查詢執行成功，但回傳結果為空。請檢查查詢條件。',
                 type: 'warning'
             });
          }

      } catch (e: any) {
          let errorMsg = "抱歉，執行查詢時發生錯誤。";
          if (e.message) errorMsg += `\n\n${e.message}`;

          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            sender: Sender.BOT,
            text: errorMsg,
            type: 'text'
          }]);
      } finally {
          setIsLoading(false);
      }
  };

  const handleBackToConfig = () => {
    setAppState(AppState.CONFIGURING_JOIN);
  }

  const handleExportExcel = () => {
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(previewJoinRows);
      XLSX.utils.book_append_sheet(wb, ws, "Result");
      XLSX.writeFile(wb, "QueryResult.xlsx");
      
      setAppState(AppState.IDLE);
      setCurrentJoinConfig(null);
      setSelectedTableNames([]);
      setPreviewJoinRows([]);
      setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: Sender.BOT,
          text: "✅ 資料處理完成並已匯出 Excel！",
          type: 'text'
      }]);
  };

  const isInputDisabled = appState !== AppState.IDLE && appState !== AppState.CONFIRMING_ACTION;

  return (
    <div className="flex flex-col md:flex-row h-screen bg-slate-50 overflow-hidden">
      
      {/* Alert Modal */}
      {alertState.isOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fade-in">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden border border-slate-200">
                  <div className={`p-4 flex items-center gap-3 border-b ${
                      alertState.type === 'error' ? 'bg-red-50 border-red-100 text-red-700' : 
                      alertState.type === 'warning' ? 'bg-amber-50 border-amber-100 text-amber-700' : 
                      'bg-blue-50 border-blue-100 text-blue-700'
                  }`}>
                      {alertState.type === 'error' ? <X size={24}/> : <AlertTriangle size={24}/>}
                      <h3 className="font-bold text-lg">{alertState.title}</h3>
                  </div>
                  <div className="p-6">
                      <p className="text-slate-600 whitespace-pre-wrap leading-relaxed">{alertState.message}</p>
                  </div>
                  <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
                      <button 
                          onClick={() => setAlertState(prev => ({...prev, isOpen: false}))}
                          className="px-6 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg transition-colors font-medium"
                      >
                          確認 (OK)
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* API Preview Modal */}
      {apiPreviewModal.visible && apiPreviewModal.data && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fade-in">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-200 flex flex-col max-h-[90vh]">
                  <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                      <h3 className="font-bold text-slate-800 flex items-center gap-2">
                          <Server size={18} className="text-indigo-600"/>
                          API 執行預覽
                      </h3>
                      <button onClick={() => setApiPreviewModal({visible: false, data: null})} className="text-slate-400 hover:text-slate-600">
                          <X size={20} />
                      </button>
                  </div>
                  
                  <div className="p-6 overflow-y-auto space-y-4">
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">API Name</label>
                          <div className="text-sm font-medium text-slate-800">{apiPreviewModal.data.apiName}</div>
                      </div>
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">Request Path</label>
                          <div className="flex items-center gap-2 bg-slate-100 p-2 rounded border border-slate-200 font-mono text-sm">
                              <span className="font-bold text-green-700">{apiPreviewModal.data.method}</span>
                              <span className="text-slate-600">{apiPreviewModal.data.url}</span>
                          </div>
                      </div>
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">Payload / Query Params</label>
                          <pre className="bg-slate-900 text-slate-50 p-3 rounded-lg text-xs font-mono overflow-x-auto border border-slate-700">
                              {JSON.stringify(apiPreviewModal.data.payload, null, 2)}
                          </pre>
                      </div>
                  </div>

                  <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-3">
                      <button 
                          onClick={() => setApiPreviewModal({visible: false, data: null})}
                          className="px-4 py-2 text-slate-600 hover:bg-slate-200 font-medium rounded-lg transition-colors text-sm"
                      >
                          取消
                      </button>
                      <button 
                          onClick={handleExecuteApi}
                          className="flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-sm transition-all active:scale-[0.98]"
                      >
                          <Play size={16} />
                          確認執行
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Sidebar - Controls & Input */}
      <aside className="w-full md:w-80 lg:w-96 flex-shrink-0 bg-white border-r border-slate-200 flex flex-col z-20 shadow-md md:h-full">
        {/* Header Branding */}
        <div className="p-6 border-b border-slate-100 bg-white flex-shrink-0 flex flex-col gap-4">
            <div className="flex items-center gap-3">
                <div className="bg-indigo-600 p-2 rounded-lg text-white shadow-sm">
                    <Sparkles size={24} />
                </div>
                <div>
                    <h1 className="text-xl font-bold text-slate-800 tracking-tight">IntelliQuery</h1>
                    <p className="text-xs text-slate-500 font-medium">AI 驅動的資料庫助手</p>
                </div>
            </div>

            {/* Mode Switcher */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <span className="text-xs font-medium text-slate-600">
                    資料來源
                    <span className="ml-1 text-[10px] text-slate-400 font-normal block">
                        {isMockMode ? '模擬數據 (Mock)' : '真實 API'}
                    </span>
                </span>
                <button
                    onClick={handleToggleMockMode}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ${isMockMode ? 'bg-green-500' : 'bg-slate-300'}`}
                    title={isMockMode ? "點擊切換為真實 API" : "點擊切換為模擬資料"}
                >
                    <span className={`${isMockMode ? 'translate-x-6' : 'translate-x-1'} inline-block h-4 w-4 transform rounded-full bg-white transition-transform shadow-sm`} />
                </button>
            </div>
        </div>

        {/* Sidebar Middle - Selected Tables List */}
        <div className="flex-1 overflow-y-auto bg-slate-50/50 p-4">
             {selectedTableNames.length > 0 ? (
                <div className="animate-fade-in">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                            <Database size={14} className="text-indigo-500"/>
                            已選取的資料表
                            <span className="bg-indigo-100 text-indigo-700 text-[10px] px-1.5 py-0.5 rounded-full">{selectedTableNames.length}</span>
                        </h3>
                        <button 
                            onClick={handleClearAllTables}
                            className="flex items-center gap-1 text-[10px] text-red-400 hover:text-red-600 hover:bg-red-50 px-2 py-1 rounded transition-colors"
                        >
                            <Trash2 size={12} />
                            全部清除
                        </button>
                    </div>
                    <div className="space-y-2">
                        {selectedTableNames.map((name) => (
                            <div key={name} className="flex items-center justify-between bg-white border border-slate-200 p-2.5 rounded-lg shadow-sm group hover:border-indigo-300 transition-all">
                                <span className="text-sm text-slate-700 font-medium truncate w-[200px]" title={name}>{name}</span>
                                <button 
                                    onClick={() => handleRemoveSelectedTable(name)}
                                    className="text-slate-400 hover:text-red-500 p-1 rounded-md hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
                                    title="移除"
                                >
                                    <X size={14} />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
             ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 text-sm italic p-4 text-center">
                    <Database size={32} className="mb-2 opacity-20" />
                    <p>尚未選取任何資料表</p>
                </div>
             )}
        </div>
        
        {/* Sidebar Bottom - Input Area */}
        <div className="p-4 border-t border-slate-200 bg-white flex-shrink-0">
            <div className="flex flex-col gap-3">
                <div className={`space-y-2 transition-all duration-300 ${isInputDisabled ? 'opacity-50 grayscale' : ''}`}>
                    <label className="text-sm font-bold text-slate-700 flex items-center justify-between">
                        您的查詢需求
                        {appState === AppState.ANALYZING && <Loader2 className="animate-spin text-indigo-600" size={14} />}
                    </label>
                    <div className="relative">
                        <textarea
                            ref={textareaRef}
                            rows={3}
                            value={inputText}
                            onChange={(e) => setInputText(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder={isInputDisabled ? "請先完成目前的互動..." : "請輸入查詢需求 (例如：列出所有產品)"}
                            disabled={isInputDisabled}
                            className="w-full p-3 pr-10 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none text-slate-800 placeholder:text-slate-400 text-sm shadow-sm transition-all disabled:bg-slate-50"
                        />
                        <div className="absolute bottom-3 right-3">
                            <button
                                onClick={handleSendMessage}
                                disabled={(!inputText.trim()) || isInputDisabled}
                                className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg disabled:text-slate-300 disabled:hover:bg-transparent transition-colors"
                            >
                                <Send size={18} />
                            </button>
                        </div>
                    </div>
                    {!isInputDisabled && (
                        <p className="text-xs text-slate-400 text-right">按 Enter 發送</p>
                    )}
                </div>
            </div>
             <div className="mt-4 text-[10px] text-slate-400 text-center">
                Gemini 可能會顯示不準確的資訊，請核對重要資訊。
            </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col relative min-w-0 bg-slate-50/50">
        
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth">
            <div className="max-w-4xl mx-auto flex flex-col pb-10">
                {messages.map((msg) => (
                    <ChatMessageBubble key={msg.id} message={msg} />
                ))}
                
                {/* Interactive Components render inside the chat flow visually */}
                
                {appState === AppState.ANALYZING && (
                    <div className="flex items-center gap-2 text-slate-500 text-sm ml-2 animate-pulse mb-6">
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        <span className="ml-1">AI 正在處理中...</span>
                    </div>
                )}

                {appState === AppState.SELECTING_TABLE && (
                    <TableSelection 
                        recommendations={recommendations}
                        selectedTables={selectedTableNames}
                        onSelect={handleTableSelect} 
                        onCancel={handleCancelSelection} 
                    />
                )}

                {/* Loading State for Table Preview */}
                {appState === AppState.PREVIEWING_DATA && isLoading && (
                     <SkeletonTable />
                )}

                {appState === AppState.PREVIEWING_DATA && previewData && !isLoading && (
                    <div className="flex flex-col gap-4 mb-6">
                        <DataPreview 
                            data={previewData} 
                        />
                        
                        {/* Action Buttons for Preview Mode */}
                        <div className="flex items-center justify-end gap-3 animate-fade-in">
                            <button 
                                onClick={handleBackToSelection}
                                className="flex items-center justify-center gap-2 px-6 py-2.5 text-slate-600 bg-white border border-slate-300 hover:bg-slate-50 font-medium rounded-lg transition-colors active:bg-slate-100 shadow-sm"
                            >
                                <ArrowLeft size={18} />
                                返回上一步
                            </button>
                            <button 
                                onClick={handleConfirmTable}
                                className="flex items-center justify-center gap-2 px-6 py-2.5 text-white bg-indigo-600 hover:bg-indigo-700 font-medium rounded-lg shadow-sm transition-all active:scale-[0.98]"
                            >
                                <Check size={18} />
                                確認選取
                            </button>
                        </div>
                    </div>
                )}
                
                {appState === AppState.CONFIRMING_ACTION && (
                    <div className="w-full mt-6 mb-8 animate-fade-in grid grid-cols-2 gap-4">
                        <button 
                            onClick={handleContinueSelection}
                            className="flex flex-col items-center justify-center p-6 bg-white border border-indigo-100 hover:border-indigo-300 rounded-xl shadow-sm hover:shadow-md hover:bg-indigo-50 transition-all group text-center"
                        >
                            <div className="p-4 bg-indigo-100 text-indigo-600 rounded-full group-hover:bg-indigo-200 transition-colors shadow-sm mb-3">
                                <Plus size={28} />
                            </div>
                            <div>
                                <span className="block text-lg font-bold text-slate-800 mb-1">繼續選取其他表</span>
                                <span className="text-sm text-slate-500">加入更多資料表進行關聯</span>
                            </div>
                        </button>

                        <button 
                            onClick={handleProceedToConfiguration}
                            className="flex flex-col items-center justify-center p-6 bg-white border border-green-100 hover:border-green-300 rounded-xl shadow-sm hover:shadow-md hover:bg-green-50 transition-all group text-center"
                        >
                            <div className="p-4 bg-green-100 text-green-600 rounded-full group-hover:bg-green-200 transition-colors shadow-sm mb-3">
                                <ArrowRight size={28} />
                            </div>
                            <div>
                                <span className="block text-lg font-bold text-slate-800 mb-1">下一步</span>
                                <span className="text-sm text-slate-500">完成選取，設定關聯</span>
                            </div>
                        </button>
                    </div>
                )}

                {/* Join Configuration Skeleton */}
                {appState === AppState.CONFIGURING_JOIN && isLoading && (
                    <SkeletonJoinConfig />
                )}

                {appState === AppState.CONFIGURING_JOIN && currentJoinConfig && !isLoading && (
                    <JoinConfiguration
                        config={currentJoinConfig}
                        allSchemas={DB_SCHEMA}
                        onConfirm={handleShowJoinPreview}
                        onCancel={handleCancelSelection}
                        onBack={handleBackToConfirmation}
                    />
                )}

                {/* Loading State for Join Preview */}
                {appState === AppState.PREVIEWING_JOIN && isLoading && (
                     <SkeletonTable hasSql={true} />
                )}

                {appState === AppState.PREVIEWING_JOIN && !isLoading && (
                    <JoinDataPreview 
                        sql={generatedSql}
                        data={previewJoinRows}
                        columns={previewJoinColumns}
                        onBack={handleBackToConfig}
                        onExport={handleExportExcel}
                    />
                )}

                <div ref={messagesEndRef} />
            </div>
        </div>
      </main>
    </div>
  );
}