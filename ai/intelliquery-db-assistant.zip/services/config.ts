// This file has been renamed to schemaConfig.ts to better reflect its purpose.
// Please import from './schemaConfig' instead.
