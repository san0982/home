

import { TableSchema, PreviewData, JoinConfig } from '../types';
import { TABLE_CONFIGS, API_CONFIGS } from './schemaConfig';

// ==========================================
// CONFIGURATION STATE
// ==========================================
// Default to true (Mock Data)
let useMockDataState = true;

/**
 * Toggle between Mock Data and Real API
 * @param enable true for Mock Data, false for Real API
 */
export const setMockMode = (enable: boolean) => {
    useMockDataState = enable;
    console.log(`[DataService] Mode switched to: ${enable ? 'Mock Data' : 'Real API'}`);
};

// Dynamic DB Schema derived from the JSON configuration
export const DB_SCHEMA: TableSchema[] = TABLE_CONFIGS.map(config => ({
  name: `${config.tableName} (${config.displayName})`,
  description: config.description,
  columns: config.columns,
  requiredWhere: config.requiredWhere,       // Mapped
  requiredWhereColumn: config.requiredWhereColumn, // Mapped
  apiId: config.apiId // Mapped
}));

// ==========================================
// API HANDLER (Real Data Implementation)
// ==========================================

/**
 * Internal helper to construct payload
 */
function constructApiPayload(apiConfig: any, sqlQuery: string): any {
    let payload: any = {};
    
    try {
        if (apiConfig.bodyStructure) {
            payload = JSON.parse(JSON.stringify(apiConfig.bodyStructure));
        }
    } catch (e) {
        console.warn("Failed to parse bodyStructure, using default object.");
        payload = {};
    }

    // Inject SQL into the payload
    let injected = false;

    if (payload.hasOwnProperty('sql')) {
        payload.sql = sqlQuery;
        injected = true;
    } else {
        // Try to find a string placeholder
        for (const key of Object.keys(payload)) {
            if (typeof payload[key] === 'string') {
                payload[key] = sqlQuery;
                injected = true;
                break;
            }
        }
    }

    if (!injected) {
        payload.sql = sqlQuery;
    }
    return payload;
}

async function callApi(apiId: string, sqlQuery: string): Promise<any> {
    const apiConfig = API_CONFIGS.find(api => api.id === apiId);
    if (!apiConfig) {
        throw new Error(`API Config not found for ID: ${apiId}`);
    }

    const payload = constructApiPayload(apiConfig, sqlQuery);

    try {
        console.log(`[DataService] Calling API ID: ${apiConfig.id}`);
        console.log(`[DataService] Path: ${apiConfig.path} (${apiConfig.method})`);
        console.log(`[DataService] Payload/Params:`, payload);

        let url = apiConfig.path;
        
        // Prepare headers
        const headers: HeadersInit = {
            // Add Authorization header here if needed
            // 'Authorization': `Bearer ${token}` 
        };

        const options: RequestInit = {
            method: apiConfig.method,
            headers: headers
        };

        if (apiConfig.method === 'GET') {
            // For GET requests, we typically DO NOT send Content-Type: application/json
            // as it can trigger CORS preflight issues or be rejected by some servers.
            
            const params = new URLSearchParams();
            Object.keys(payload).forEach(key => {
                if (payload[key] !== undefined && payload[key] !== null) {
                    // Check if value is object (like nested settings), JSON stringify it if so, else String
                    const val = typeof payload[key] === 'object' ? JSON.stringify(payload[key]) : String(payload[key]);
                    params.append(key, val);
                }
            });
            // Handle if url already has params
            const separator = url.includes('?') ? '&' : '?';
            url += `${separator}${params.toString()}`;
        } else {
            // For POST/PUT, we send JSON body and need Content-Type
            (headers as any)['Content-Type'] = 'application/json';
            options.body = JSON.stringify(payload);
        }

        const response = await fetch(url, options);

        if (!response.ok) {
            // Enhanced Error Message for HTTP Errors
            throw new Error(`Failed to fetch data from [${apiConfig.name}] at [${apiConfig.path}]. Status: ${response.status} ${response.statusText}. Please check the API configuration or network connection.`);
        }

        return await response.json();
    } catch (error: any) {
        console.error("API Call Error:", error);
        
        // If it's already our enhanced error, rethrow it
        if (error.message && error.message.startsWith("Failed to fetch data from")) {
            throw error;
        }

        // Generic wrapper for network/fetch errors
        throw new Error(`Failed to fetch data from [${apiConfig.name}] at [${apiConfig.path}]. Please check the API configuration or network connection. Error: ${error.message}`);
    }
}

/**
 * Helper to flatten row data for display
 * Converts nested objects to string representations
 */
function flattenRow(row: any): any {
    const newRow: any = {};
    Object.keys(row).forEach(key => {
        const val = row[key];
        if (val === null || val === undefined) {
            newRow[key] = "";
        } else if (typeof val === 'object') {
            // Flatten simple objects to string, e.g. {first: 'John'} -> "John" or JSON
            if (val.first && val.last) newRow[key] = `${val.first} ${val.last}`; // RandomUser specific check
            else newRow[key] = JSON.stringify(val);
        } else {
            newRow[key] = val;
        }
    });
    return newRow;
}

/**
 * Validates API data.
 * Returns the actual columns found in the data to support dynamic schema adaptation.
 */
function validateApiData(rows: any[], expectedColumns: string[]): string[] {
    // 1. Check for empty data
    if (!rows || rows.length === 0) {
        console.warn("[DataService] API returned empty data.");
        // We return expected columns as fallback so the table header renders (empty body)
        return expectedColumns; 
    }

    // 2. Determine Actual Columns from first row
    const firstRow = rows[0];
    const actualKeys = Object.keys(firstRow);
    
    // Check which expected columns are MISSING in the actual API response
    const missingColumns = expectedColumns.filter(col => !actualKeys.includes(col));

    if (missingColumns.length > 0) {
        console.warn(`[DataService] Schema Mismatch. Config expects: [${expectedColumns.join(', ')}], but API returned keys: [${actualKeys.join(', ')}]`);
        console.warn(`[DataService] Missing columns: ${missingColumns.join(', ')}`);
        
        // In "Real API" mode, especially for demos with randomuser.me, we prioritize showing the data we GOT
        // over enforcing the schema strictness.
        // Return actual keys so the UI updates to show what we actually received.
        return actualKeys;
    }

    return expectedColumns;
}

// ==========================================
// MOCK DATA GENERATORS (Legacy/Fallback)
// ==========================================
const getRandomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;

function generateMockRows(config: any, count: number = 10) {
    const rows = [];
    for (let i = 1; i <= count; i++) {
        const row: any = {};
        config.columns.forEach((col: string) => {
            if (col === "OrderID") row[col] = `ORD-${1000 + i}`;
            else if (col === "CustomerID") row[col] = `CUS-${1000 + ((i % 5) + 1)}`;
            else if (col === "ProductID") row[col] = `PROD-${1000 + ((i % 5) + 1)}`;
            else if (col === "EmployeeID") row[col] = `EMP-${1000 + ((i % 3) + 1)}`;
            else if (col.includes("Date")) row[col] = new Date().toISOString().split('T')[0];
            else if (col === "TotalAmount") row[col] = (Math.random() * 5000 + 100).toFixed(0);
            else if (col === "Price" || col === "UnitPrice") row[col] = (Math.random() * 500 + 10).toFixed(0);
            else if (col.includes("Quantity")) row[col] = getRandomInt(1, 20);
            else if (col === "Name") row[col] = `Customer ${String.fromCharCode(65 + ((i % 5)))}`;
            else if (col === "Status") row[col] = i % 3 === 0 ? "Cancelled" : "Completed";
            else if (col === "ProductName") row[col] = `Product ${String.fromCharCode(80 + ((i % 5)))}`;
            else row[col] = `Data ${i}`;
        });
        rows.push(row);
    }
    return rows;
}

// ==========================================
// PUBLIC SERVICE METHODS
// ==========================================

/**
 * Helper to resolve table config from a potentially composite name (e.g. "Orders (訂單)")
 * USES STRICT MATCHING to prevent substring collisions (e.g. 'myorders' matching 'Orders').
 */
export const resolveTableConfig = (name: string) => {
    if (!name) return undefined;
    const normalizedRequest = name.toLowerCase().trim();
    
    // Strict matching against TableName, DisplayName, or "TableName (DisplayName)"
    return TABLE_CONFIGS.find(t => {
        const tName = t.tableName.toLowerCase();
        const tDisplay = t.displayName.toLowerCase();
        const tCombined = `${t.tableName} (${t.displayName})`.toLowerCase();

        return (
            normalizedRequest === tName ||
            normalizedRequest === tDisplay ||
            normalizedRequest === tCombined
        );
    });
};

/**
 * Returns the API request details for a given table without executing it.
 * Used for previewing the request in API mode.
 */
export const getApiPreviewForTable = (tableName: string) => {
    const config = resolveTableConfig(tableName);
    if (!config) throw new Error(`Table ${tableName} not found.`);

    const apiConfig = API_CONFIGS.find(api => api.id === config.apiId);
    if (!apiConfig) throw new Error(`API Config not found for ID: ${config.apiId}`);

    let sqlQuery = `SELECT * FROM ${config.tableName}`;
    if (config.requiredWhere) {
        sqlQuery += ` WHERE ${config.requiredWhereColumn || 'Column'} = '?'`;
    }
    sqlQuery += ` LIMIT 10`;

    const payload = constructApiPayload(apiConfig, sqlQuery);

    return {
        apiName: apiConfig.name,
        url: apiConfig.path,
        method: apiConfig.method,
        payload: payload,
        tableName: config.tableName // Return real table name for consistency
    };
};

/**
 * Fetch data for a single table preview.
 * Switches between Mock generation and API calls.
 */
export const fetchTableData = async (requestedTableName: string): Promise<PreviewData> => {
  // 1. Resolve Table Config
  const config = resolveTableConfig(requestedTableName);

  if (!config) {
    console.error(`[DataService] Config lookup failed for: ${requestedTableName}`);
    throw new Error(`Table ${requestedTableName} not found in configuration.`);
  }

  console.log(`[DataService] Resolved Table: ${config.tableName}, using API ID: ${config.apiId}`);

  const displayTitle = `${config.tableName} (${config.displayName})`;

  // 2. Fetch Data (Mock or Real)
  let rows: any[] = [];
  let displayColumns = config.columns;

  if (useMockDataState) {
      console.log(`[DataService] Fetching Mock Data for ${config.tableName}`);
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 600)); 
      rows = generateMockRows(config, 10);
  } else {
      console.log(`[DataService] Fetching Real API Data for ${config.tableName}`);
      // Call Real API
      // Construct a basic SQL query for preview
      let sqlQuery = `SELECT * FROM ${config.tableName}`;
      if (config.requiredWhere) {
          sqlQuery += ` WHERE ${config.requiredWhereColumn || 'Column'} = '?'`;
      }
      sqlQuery += ` LIMIT 10`;
      
      const apiResult = await callApi(config.apiId, sqlQuery);
      
      // Robust Check: Ensure result is an array
      if (Array.isArray(apiResult)) {
          rows = apiResult;
      } else if (apiResult && Array.isArray(apiResult.data)) {
          rows = apiResult.data;
      } else if (apiResult && Array.isArray(apiResult.results)) {
          rows = apiResult.results;
      } else {
          console.warn("[DataService] API did not return an array in expected fields (root, .data, .results). Fallback to empty.", apiResult);
          // Try to see if there is ANY array property we can use as fallback
          const keys = Object.keys(apiResult || {});
          const arrayKey = keys.find(k => Array.isArray(apiResult[k]));
          if (arrayKey) {
              console.log(`[DataService] Found array in property '${arrayKey}', using it.`);
              rows = apiResult[arrayKey];
          } else {
              rows = [];
          }
      }

      // VALIDATE DATA & ADAPT SCHEMA
      // This will check if columns match. If rows is empty, it returns config.columns
      const actualColumns = validateApiData(rows, config.columns);
      
      // If columns mismatch, update display columns to show what we actually got
      if (actualColumns.length > 0 && actualColumns.join(',') !== config.columns.join(',')) {
          displayColumns = actualColumns;
          // Clean up rows for display (flatten objects)
          rows = rows.map(flattenRow);
      }
  }

  return {
    tableName: displayTitle,
    columns: displayColumns,
    rows: rows
  };
};

/**
 * Fetch data for a JOIN query.
 * Switches between Client-side Mock Join and Server-side API Join.
 * 
 * @param tableNames List of tables involved
 * @param joinConfig The configuration for the join
 * @param sqlQuery The generated SQL query string (optional, used for Real API)
 */
export const fetchJoinData = async (
    tableNames: string[], 
    joinConfig: JoinConfig,
    sqlQuery: string = ""
): Promise<any[]> => {
    
    if (useMockDataState) {
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 800));
        return executeMockJoin(tableNames, joinConfig.joins, joinConfig.selectedColumns);
    } else {
        // Call Real API
        const primaryTableConfig = resolveTableConfig(joinConfig.primaryTable);
        const apiId = primaryTableConfig ? primaryTableConfig.apiId : "API_001"; // Fallback to default if not found
        
        console.log(`[DataService] Join Query. Primary Table Input: ${joinConfig.primaryTable}`);
        console.log(`[DataService] Resolved Config: ${primaryTableConfig?.tableName}, Using API ID: ${apiId}`);

        const apiResult = await callApi(apiId, sqlQuery);
        
        let rows: any[] = [];
        // Robust Check: Ensure result is an array
        if (Array.isArray(apiResult)) {
            rows = apiResult;
        } else if (apiResult && Array.isArray(apiResult.data)) {
            rows = apiResult.data;
        } else if (apiResult && Array.isArray(apiResult.results)) {
            rows = apiResult.results;
        } else {
             console.warn("[DataService] Join API response is not an array. Fallback to empty.", apiResult);
             rows = [];
        }

        // Flatten for display if we have data
        if (rows.length > 0) {
            return rows.map(flattenRow);
        }
        
        return [];
    }
};

// ==========================================
// INTERNAL MOCK JOIN LOGIC
// ==========================================
const executeMockJoin = (
    tableNames: string[], 
    joinKeys: { leftTable: string, rightTable: string, onKeys: { leftColumn: string, rightColumn: string }[] }[],
    selectedColumns: { [key: string]: string[] }
): any[] => {
    
    // 1. Get data for all tables
    const tableDataMap: { [key: string]: any[] } = {};
    
    tableNames.forEach(name => {
        try {
            // Find config to generate data
            const config = resolveTableConfig(name);
            if (config) {
                tableDataMap[config.tableName] = generateMockRows(config, 15); // Generate slightly more for matches
                // Alias mapping for both system name and display name if needed
                tableDataMap[name] = tableDataMap[config.tableName];
            }
        } catch (e) {
            console.warn(`Could not load mock data for join table: ${name}`);
        }
    });

    if (Object.keys(tableDataMap).length === 0) return [];
    
    // 2. Identify Primary Table
    const firstTableInput = tableNames[0];
    const firstConfig = resolveTableConfig(firstTableInput);
    const primaryTableKey = firstConfig ? firstConfig.tableName : firstTableInput;

    // PREFIX PRIMARY TABLE DATA to support internal namespacing logic
    let resultRows = (tableDataMap[primaryTableKey] || []).map(row => {
        const prefixed: any = {};
        Object.keys(row).forEach(key => {
            prefixed[`${primaryTableKey}.${key}`] = row[key];
        });
        return prefixed;
    });

    // 3. Iteratively join
    for (const join of joinKeys) {
        // Resolve right table key
        const rightConfig = resolveTableConfig(join.rightTable);
        const rightKey = rightConfig ? rightConfig.tableName : join.rightTable;
        
        // rightRows are RAW
        const rightRows = tableDataMap[rightKey]; 
        
        if (!rightRows) continue;

        resultRows = resultRows.map(leftRow => {
            // Check match using namespaced left key and raw right key
            const match = rightRows.find(rightRow => {
                return join.onKeys.every(k => {
                    const leftVal = leftRow[`${join.leftTable}.${k.leftColumn}`];
                    const rightVal = rightRow[k.rightColumn];
                    return leftVal === rightVal;
                });
            });

            const rightDataToMerge: any = {};
            if (match) {
                 // Merge all columns from matched row, prefixed with current table name
                 // This ensures future joins have access to this table's data
                 Object.keys(match).forEach(rawKey => {
                     rightDataToMerge[`${join.rightTable}.${rawKey}`] = match[rawKey];
                 });
            }
            return { ...leftRow, ...rightDataToMerge };
        });
    }

    // 4. Filter columns and rename to "Table.Column" format
    const finalResult = resultRows.map(row => {
        const newRow: any = {};
        Object.keys(selectedColumns).forEach(tbl => {
            selectedColumns[tbl].forEach(col => {
                const namespacedKey = `${tbl}.${col}`;
                if (row[namespacedKey] !== undefined) {
                    newRow[namespacedKey] = row[namespacedKey];
                } else {
                    newRow[namespacedKey] = null; // Ensure key exists
                }
            });
        });
        return newRow;
    });

    return finalResult;
};