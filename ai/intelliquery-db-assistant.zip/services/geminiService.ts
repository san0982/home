import { GoogleGenAI, Type, GenerateContentParameters } from "@google/genai";
import { TableSchema, TableRecommendation, JoinConfig } from "../types";

// Initialize Gemini Client
// CRITICAL: process.env.API_KEY is handled by the runtime environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = "gemini-3-pro-preview";
//const MODEL_NAME = "gemini-2.5-pro";

// Retry configuration
const MAX_RETRIES = 3;
const INITIAL_BACKOFF = 1000;

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Helper to safely extract status code from various error shapes
 */
function getErrorStatus(error: any): number | undefined {
    if (typeof error?.status === 'number') return error.status;
    if (typeof error?.response?.status === 'number') return error.response.status;
    if (typeof error?.error?.code === 'number') return error.error.code;
    if (typeof error?.code === 'number') return error.code;
    return undefined;
}

/**
 * Helper to call Gemini API with retry logic for transient errors.
 */
async function generateContentWithRetry(params: GenerateContentParameters, retries = MAX_RETRIES): Promise<any> {
    try {
        return await ai.models.generateContent(params);
    } catch (error: any) {
        const status = getErrorStatus(error);

        // Retry on network errors (503 Service Unavailable, 500 Internal Server Error, 502 Bad Gateway, 504 Gateway Timeout) 
        // or Rate Limits (429)
        // Also handle standard fetch failures
        const isTransient = 
            status === 503 || 
            status === 429 || 
            status === 500 || 
            status === 502 || 
            status === 504 || 
            error.message?.includes('fetch failed') ||
            error.message?.includes('Network request failed');
        
        if (isTransient && retries > 0) {
            // Exponential backoff: 1s, 2s, 4s...
            const attempt = MAX_RETRIES - retries + 1;
            const waitTime = INITIAL_BACKOFF * Math.pow(2, attempt - 1);
            
            console.warn(`Gemini API request failed (Status: ${status || 'Unknown'}). Retrying in ${waitTime}ms... (Attempt ${attempt} of ${MAX_RETRIES}).`);
            await delay(waitTime);
            return generateContentWithRetry(params, retries - 1);
        }
        
        // Enhance error logging for debugging
        if (status === 400) {
            console.error("Gemini API Bad Request (400). Check schema or prompt parameters.", error);
        } else if (status === 401 || status === 403) {
             console.error("Gemini API Authorization Error. Check API_KEY.", error);
        } else if (status === 404) {
             console.error("Gemini Model not found (404). Check MODEL_NAME.", error);
        } else if (status === 429) {
             console.warn("Gemini API Quota Exceeded (429). Stop Retrying.");
        } else {
             console.error("Gemini API Unexpected Error:", error);
        }

        throw error;
    }
}

export const getTableRecommendations = async (
  userQuery: string,
  schema: TableSchema[],
  selectedTableNames: string[] = []
): Promise<TableRecommendation[]> => {
  
  // Logic: We used to strictly filter by API ID here, but it caused confusion ("Not Found")
  // when users asked for incompatible tables. 
  // Now we pass the FULL schema but provide context to the AI to prioritize the active source.
  // The UI (App.tsx) handles the strict blocking if the user selects an incompatible table.
  
  let activeSchema = schema;
  let contextMsg = "";

  if (selectedTableNames.length > 0) {
      // Find the API ID of the first selected table
      const firstSelectedTable = schema.find(t => t.name === selectedTableNames[0]);
      
      if (firstSelectedTable && firstSelectedTable.apiId) {
          const targetApiId = firstSelectedTable.apiId;
          
          // Remove tables that are already selected to prevent recommending them again
          activeSchema = schema.filter(t => !selectedTableNames.includes(t.name));
          
          console.log(`[GeminiService] Context: User is working with Source ID: ${targetApiId}.`);

          contextMsg = `
          CONTEXT:
          The user has ALREADY selected tables from Source ID "${targetApiId}".
          
          GUIDELINES:
          1. PRIORITIZE recommending tables that also belong to Source ID "${targetApiId}".
          2. However, if the user explicitly asks for a table from a DIFFERENT source (that fits their query perfectly), you MAY recommend it.
             (The system will handle the compatibility check later).
          `;
      }
  }

  const schemaDescription = activeSchema.map(t => `- ${t.name}: ${t.description} [Source: ${t.apiId || 'Unknown'}]`).join('\n');

  const prompt = `
    使用者需求: "${userQuery}"
    
    ${contextMsg}

    可用資料庫結構 (Candidate Tables):
    ${schemaDescription}
    
    請根據使用者需求，推薦最相關的資料表。
    
    重要規則:
    1. 當推薦多張資料表時，請優先推薦具有相同 [Source: ID] 的資料表。
    2. 請只回傳最可能需要的 1-3 個資料表。
    3. 如果使用者提到的資料表在不同 Source，請推薦與語意最相符的那個。
    4. 如果沒有適合的資料表，回傳空陣列。
  `;

  try {
    const response = await generateContentWithRetry({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        systemInstruction: "你是一位資深資料庫管理員。請根據使用者的自然語言查詢，分析最適合的資料表。",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              tableName: {
                type: Type.STRING,
                description: "The exact name of the table from the provided schema."
              },
              reason: {
                type: Type.STRING,
                description: "A short explanation in Traditional Chinese (繁體中文) why this table is relevant."
              }
            },
            required: ["tableName", "reason"]
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as TableRecommendation[];
    }
    return [];
  } catch (error: any) {
    const status = getErrorStatus(error);
    if (status === 429) {
        console.warn("Skipping recommendation due to Quota Exceeded (429).");
        // We throw so App.tsx can handle the alert
        throw error;
    }
    console.error("Gemini API Error in getTableRecommendations:", error);
    return [];
  }
};

// Internal interface for AI response to match the Array schema
interface AIJoinResponse {
    primaryTable: string;
    joins: {
        leftTable: string;
        rightTable: string;
        // Old fields for fallback
        leftColumn?: string;
        rightColumn?: string;
        // New structure
        onKeys?: { leftColumn: string, rightColumn: string }[];
    }[];
    tableColumns: {
        tableName: string;
        columns: string[];
    }[];
    whereConditions?: {
        tableName: string;
        column: string;
        value: string;
    }[];
}

export const suggestJoinConfiguration = async (
    tableNames: string[],
    schema: TableSchema[],
    userQuery: string
): Promise<JoinConfig | null> => {
    
    // Filter schema to only selected tables
    const relevantSchema = schema.filter(t => tableNames.includes(t.name));
    const schemaDesc = relevantSchema.map(t => {
        let desc = `Table Name: "${t.name}"\nColumns: ${t.columns.join(', ')}`;
        if (t.requiredWhere && t.requiredWhereColumn) {
            desc += `\n**MANDATORY FILTER REQUIRED**: This table MUST have a WHERE condition on column "${t.requiredWhereColumn}".`;
        }
        return desc;
    }).join('\n\n');

    const prompt = `
      User Query: "${userQuery}"
      Selected Tables: ${tableNames.join(', ')}
      
      Schemas:
      ${schemaDesc}
      
      Task:
      1. Identify the primary table (the central entity of the query).
      2. Define JOIN relationships (LEFT JOIN logic).
         - NOTE: If multiple columns are needed to join (composite key), include them all in 'onKeys'.
      3. Select relevant columns for each table (Output Columns):
         - **Strategy**: Prioritize readability and relevance over technical completeness.
         - **Explicit**: Always include columns explicitly mentioned in the 'User Query'.
         - **Descriptive**: Include 'human-readable' columns (e.g., Name, ProductName, Email, Status, Date) rather than just IDs.
         - **Redundancy Check**: If Table A joins Table B, and Table B provides a descriptive name (e.g. 'CustomerName'), do NOT select the Foreign Key (e.g. 'CustomerID') from Table A unless explicitly asked.
         - **Primary Keys**: It is okay to include the Primary Key of the main table (e.g. 'OrderID') for reference.
         - **Limit**: Select only 3-5 columns per table to avoid noise, unless the user asks for "all details" or "*".
      4. **CRITICAL**: If a table has a MANDATORY FILTER REQUIRED (see schema), try to find the specific value for that column in the 'User Query'. 
         Example: If query is "2023 orders" and Orders table requires 'OrderDate', extract "2023" or the relevant date format. If not found, leave value empty.
      
      IMPORTANT: 
      - Use the EXACT table names provided in the Schemas (including any Chinese characters like "(訂單)").
      - Do NOT shorten or translate table names.
      - Do NOT make up columns.
    `;

    try {
        // Attempt 1: Strict Schema with Retry
        const response = await generateContentWithRetry({
            model: MODEL_NAME,
            contents: prompt,
            config: {
                systemInstruction: "You are a SQL Expert. Return a JSON configuration. ALWAYS use the exact Table Names provided in the context.",
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        primaryTable: { type: Type.STRING },
                        joins: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    leftTable: { type: Type.STRING },
                                    rightTable: { type: Type.STRING },
                                    // New structure for multiple keys
                                    onKeys: {
                                        type: Type.ARRAY,
                                        items: {
                                            type: Type.OBJECT,
                                            properties: {
                                                leftColumn: { type: Type.STRING },
                                                rightColumn: { type: Type.STRING }
                                            },
                                            required: ["leftColumn", "rightColumn"]
                                        }
                                    }
                                },
                                required: ["leftTable", "rightTable", "onKeys"]
                            }
                        },
                        // Changed from dynamic Map object to Array of objects to satisfy strict schema requirements
                        tableColumns: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    tableName: { type: Type.STRING },
                                    columns: {
                                        type: Type.ARRAY,
                                        items: { type: Type.STRING }
                                    }
                                },
                                required: ["tableName", "columns"]
                            }
                        },
                        // New field for extracted conditions
                        whereConditions: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    tableName: { type: Type.STRING },
                                    column: { type: Type.STRING },
                                    value: { type: Type.STRING }
                                },
                                required: ["tableName", "column", "value"]
                            }
                        }
                    },
                    required: ["primaryTable", "joins", "tableColumns"]
                }
            }
        });
        
        if (response.text) {
            const raw = JSON.parse(response.text) as AIJoinResponse;
            
            // Normalize Joins to new structure if somehow old format slips in (unlikely with strict schema but safe)
            const normalizedJoins = raw.joins.map(j => ({
                leftTable: j.leftTable,
                rightTable: j.rightTable,
                onKeys: j.onKeys || (j.leftColumn && j.rightColumn ? [{leftColumn: j.leftColumn, rightColumn: j.rightColumn}] : [])
            }));

            // Convert Array format back to Map format for the App
            const selectedColumnsMap: { [key: string]: string[] } = {};
            if (raw.tableColumns) {
                raw.tableColumns.forEach(item => {
                    selectedColumnsMap[item.tableName] = item.columns;
                });
            }

            // Convert Where Conditions to Map
            const whereMap: { [key: string]: { column: string, value: string } } = {};
            if (raw.whereConditions) {
                raw.whereConditions.forEach(item => {
                    whereMap[item.tableName] = { column: item.column, value: item.value };
                });
            }

            return {
                primaryTable: raw.primaryTable,
                joins: normalizedJoins,
                selectedColumns: selectedColumnsMap,
                whereConditions: whereMap
            };
        }

    } catch (e: any) {
        const status = getErrorStatus(e);
        if (status === 429) throw e; // Propagate quota error

        console.warn("Strict Schema Parse Failed or API Error, retrying with loose schema. Error:", e.message);
    }

    // Fallback: Retry with looser constraint
    try {
        const rawResponse = await generateContentWithRetry({
            model: MODEL_NAME,
            contents: prompt,
            config: {
                systemInstruction: "You are a SQL Expert. Return valid JSON only. Structure: { primaryTable: string, joins: [{leftTable, rightTable, onKeys: [{leftColumn, rightColumn}] }], tableColumns: [{ tableName: string, columns: string[] }], whereConditions: [{tableName, column, value}] }.",
                responseMimeType: "application/json"
            }
        });

        if (rawResponse.text) {
            const raw = JSON.parse(rawResponse.text);
            
            // Handle both potential formats from loose mode (Map or Array)
            let selectedColumnsMap: { [key: string]: string[] } = {};
            
            if (Array.isArray(raw.tableColumns)) {
                 raw.tableColumns.forEach((item: any) => {
                    selectedColumnsMap[item.tableName] = item.columns;
                });
            } else if (raw.selectedColumns) {
                selectedColumnsMap = raw.selectedColumns;
            }

            // Normalize Joins
            const normalizedJoins = (raw.joins || []).map((j: any) => ({
                leftTable: j.leftTable,
                rightTable: j.rightTable,
                onKeys: j.onKeys || (j.leftColumn && j.rightColumn ? [{leftColumn: j.leftColumn, rightColumn: j.rightColumn}] : [])
            }));

            // Handle Where Conditions
            const whereMap: { [key: string]: { column: string, value: string } } = {};
            if (Array.isArray(raw.whereConditions)) {
                 raw.whereConditions.forEach((item: any) => {
                     whereMap[item.tableName] = { column: item.column, value: item.value };
                 });
            }

            return {
                primaryTable: raw.primaryTable,
                joins: normalizedJoins,
                selectedColumns: selectedColumnsMap,
                whereConditions: whereMap
            };
        }
    } catch (e: any) {
        const status = getErrorStatus(e);
        if (status === 429) throw e;
        console.error("Failed to parse join config after fallback", e);
    }

    return null;
}

export const generateNaturalResponse = async (input: string): Promise<string> => {
    try {
        const response = await generateContentWithRetry({
            model: MODEL_NAME,
            contents: input,
            config: {
                 // Updated instruction to handle "Not Found" case strictly
                 systemInstruction: "你是一位資料庫助手。系統無法根據使用者的輸入找到對應的資料表。\n\n規則：\n1. 若輸入為閒聊或問候（如「你好」），請禮貌回應。\n2. 若輸入為查詢意圖，請回答：「抱歉，找不到符合您需求的資料表。」\n3. 不要解釋原因，不要提供建議，保持回答簡短。"
            }
        });
        return response.text || "抱歉，找不到符合您需求的資料表。";
    } catch (e: any) {
        const status = getErrorStatus(e);
        console.error(`Error in generateNaturalResponse (Status: ${status})`);
        
        // Return user-friendly error messages based on status
        if (status === 429) {
            return "⚠️ 系統目前使用量已達上限 (Rate Limit Exceeded)，請稍後再試。";
        }
        if (status === 503 || status === 500 || status === 502) {
            return "AI 服務暫時無法使用，請稍後再試 (Service Unavailable)。";
        }
        if (e.message?.includes('fetch failed') || e.message?.includes('Network request failed')) {
            return "網路連線異常，請檢查您的網路狀態。";
        }
        
        return "系統發生錯誤，請稍後再試。";
    }
}