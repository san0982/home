
import { ApiConfig, TableConfig } from '../types';

/**
 * API Configuration Table
 * 記錄 API 名稱、路徑以及 POST 格式 (改為 SQL 模式)
 */
export const API_CONFIGS: ApiConfig[] = [
  {
    id: "API_001",
    name: "General SQL Query API",
    path: "https://randomuser.me/api/",
    method: "GET",
    bodyStructure: {
      results: 10,
      sql: "SELECT * FROM TableName WHERE Condition"
    }
  },
  {
    id: "API_002",
    name: "Customer Data API",
    path: "https://randomuser.me/api/", 
    method: "GET",
    bodyStructure: {
      results: 10,
      sql: "SELECT * FROM Customers"
    }
  },
  {
    id: "API_003",
    name: "Order Data API",
    path: "https://randomuser.me/api/",
    method: "GET",
    bodyStructure: {
      results: 10,
      sql: "SELECT * FROM Orders"
    }
  },
  {
    id: "MYAPI_001",
    name: "MY Order Data API",
    path: "http://localhost:3000/api/v1/test",
    method: "GET",
    bodyStructure: {
      results: 10,
      sql: "SELECT * FROM Orders"
    }
  }
];

/**
 * Table Configuration Table
 * 包含 Table 名稱、說明、欄位、是否必要 where 條件、必要 where 欄位、API 名稱
 */
export const TABLE_CONFIGS: TableConfig[] = [
  {
    tableName: "Orders",
    displayName: "訂單",
    description: "包含所有客戶訂單紀錄，如訂單日期、總金額、狀態等。",
    columns: ["OrderID", "CustomerID", "OrderDate", "TotalAmount", "Status"],
    requiredWhere: true,
    requiredWhereColumn: "OrderDate",
    apiId: "API_003"
  },
  {
    tableName: "Customers",
    displayName: "客戶",
    description: "客戶基本資料，包含姓名、聯絡方式、地址與會員等級。",
    columns: ["CustomerID", "Name", "Email", "Phone", "Address", "MembershipLevel"],
    requiredWhere: false,
    apiId: "API_002"
  },
  {
    tableName: "Products",
    displayName: "產品",
    description: "產品庫存與詳細資訊，包含價格、類別、庫存數量。",
    columns: ["ProductID", "ProductName", "Category", "Price", "StockQuantity"],
    requiredWhere: false,
    apiId: "API_001"
  },
  {
    tableName: "OrderDetails",
    displayName: "訂單明細",
    description: "訂單內的產品明細，用於關聯訂單與產品。",
    columns: ["OrderDetailID", "OrderID", "ProductID", "Quantity", "UnitPrice"],
    requiredWhere: true,
    requiredWhereColumn: "OrderID",
    apiId: "API_001"
  },
  {
    tableName: "Employees",
    displayName: "員工",
    description: "負責處理訂單的員工資料。",
    columns: ["EmployeeID", "FirstName", "LastName", "Department", "HireDate"],
    requiredWhere: false,
    apiId: "API_001"
  },
  {
    tableName: "myorders",
    displayName: "MYAIP_訂單",
    description: "訂單資料。",
    columns: ["order_id", "order_date", "customer_id", "product_id", "quantity"],
    requiredWhere: false,
    apiId: "MYAPI_001"
  }
];
