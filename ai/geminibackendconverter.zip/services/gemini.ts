import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

// Helper to get client
const getClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface ConversionResult {
  backendApp: string;
  backendRoutes: string;
  frontend: string;
  readme: string;
}

export const convertFrontendToBackend = async (fileContent: string, fileName: string, apiPrefix: string = '/api'): Promise<ConversionResult> => {
  const ai = getClient();
  
  // Ensure consistent path formatting (no trailing slash)
  const cleanPrefix = apiPrefix.endsWith('/') && apiPrefix.length > 1 ? apiPrefix.slice(0, -1) : apiPrefix;

  // Determine language based on file extension
  const isJs = fileName.endsWith('.js') || fileName.endsWith('.jsx');
  const frontendLang = isJs ? 'JavaScript' : 'TypeScript';
  const frontendContext = isJs ? 'React/JavaScript' : 'React/TypeScript';

  const prompt = `
    You are an expert Full Stack Engineer specializing in Node.js, Express.js, React, and ${frontendLang}.
    
    I have a Frontend ${frontendContext} service file that currently interacts directly with an AI SDK (like Gemini/OpenAI).
    I need to refactor this into a Client-Server architecture using **Express.js**.

    YOUR TASK:
    Refactor the code into 4 separate files/sections:
    1.  **Backend Entry Point (server.js)**: The main Express application setup.
    2.  **Backend Routes (routes.js)**: The API logic and controllers.
    3.  **Frontend Client**: The updated client-side code.
    4.  **README.md**: Documentation for the generated backend.

    DETAILS:

    1.  **Backend Entry Point (server.js)**:
        - **LANGUAGE**: JavaScript (Node.js).
        - Setup Express, CORS, JSON body parser.
        - Load env vars via \`dotenv\`.
        - **Import and use the routes file**.
        - Mount the routes at \`${cleanPrefix}\`. 
          (e.g., \`const apiRoutes = require('./routes'); app.use('${cleanPrefix}', apiRoutes);\`)
        - Start server on port (default 3000 or process.env.PORT).

    2.  **Backend Routes (routes.js)**:
        - **LANGUAGE**: JavaScript (Node.js).
        - Create an Express Router (\`const router = express.Router();\`).
        - Convert the original frontend logic into API endpoints.
        - **API_KEY**: Get from \`process.env.API_KEY\`.
        - **BASE_URL**: Get from \`process.env.BASE_URL\` (if applicable).
        - Export the router (\`module.exports = router;\`).
        - **Path naming**: relative to the prefix (e.g., \`router.post('/chat/completions', ...)\`).

    3.  **Refactored Frontend Client (${frontendLang})**: 
        - Rewrite the original frontend file to call these new backend API endpoints using \`fetch\`.
        - **Configuration**:
            - Retrieve Backend URL from env vars (e.g., \`process.env.NEXT_PUBLIC_API_URL\`).
            - Fallback to empty string.
            - Example: \`const BASE_API_URL = process.env.NEXT_PUBLIC_API_URL || '';\`
            - Fetch URL: \`\${BASE_API_URL}${cleanPrefix}/...\`
        - Keep original function names and exports.
        - **Style**: Match original indentation and style.

    4.  **README.md**:
        - Write in **Traditional Chinese (繁體中文)**.
        - **Prerequisites**: Node.js version.
        - **Installation**: Provide \`npm install\` commands for required packages (express, dotenv, cors, etc.).
        - **Environment Variables (.env)**: explicitly list the required variables (API_KEY, BASE_URL, PORT, etc.) and explain how to create the file.
        - **Running**: Command to start the server (e.g., \`node server.js\`).

    RULES:
    1.  **Backend**: Node.js, Express, **JavaScript** (CommonJS). No types.
    2.  **Frontend**: ${frontendLang}. Use \`fetch\`.
    3.  **Comments**: Write explanatory comments in Traditional Chinese (繁體中文).
    
    OUTPUT FORMAT:
    Wrap the code blocks exactly like this:

    <BACKEND_APP_CODE>
    ... (server.js code) ...
    </BACKEND_APP_CODE>

    <BACKEND_ROUTE_CODE>
    ... (routes.js code) ...
    </BACKEND_ROUTE_CODE>

    <FRONTEND_CODE>
    ... (Frontend code) ...
    </FRONTEND_CODE>

    <README_CODE>
    ... (Markdown content) ...
    </README_CODE>

    Input Code:
    ${fileContent}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 2048 }
      }
    });

    const fullText = response.text || "";

    // Helper to extract code between tags and clean markdown
    const extractCode = (tag: string, text: string) => {
      const regex = new RegExp(`<${tag}>([\\s\\S]*?)<\/${tag}>`, 'i');
      const match = text.match(regex);
      if (!match) return `// Error: Could not generate ${tag.toLowerCase()}`;
      
      let code = match[1].trim();
      code = code.replace(/^```javascript\s*/, '').replace(/^```js\s*/, '')
                 .replace(/^```typescript\s*/, '').replace(/^```ts\s*/, '')
                 .replace(/^```markdown\s*/, '').replace(/^```md\s*/, '')
                 .replace(/```$/, '');
      return code;
    };

    const backendApp = extractCode('BACKEND_APP_CODE', fullText);
    const backendRoutes = extractCode('BACKEND_ROUTE_CODE', fullText);
    const frontend = extractCode('FRONTEND_CODE', fullText);
    const readme = extractCode('README_CODE', fullText);

    return { backendApp, backendRoutes, frontend, readme };

  } catch (error) {
    console.error("Conversion failed:", error);
    throw new Error("無法使用 Gemini 轉換代碼。");
  }
};

export const chatWithGemini = async (history: Message[], currentContextCode: string): Promise<string> => {
  const ai = getClient();
  
  const systemInstruction = `
    You are a helpful coding assistant integrated into a Code Conversion tool.
    The user has just converted a frontend service to a backend service.
    
    Current Code Context:
    ${currentContextCode.slice(0, 5000)}... (truncated if too long)
    
    Answer the user's questions about this code, Node.js best practices, or how to integrate this new file into their backend architecture.
    
    IMPORTANT: You MUST answer in Traditional Chinese (繁體中文).
    Keep answers concise and technical.
  `;

  const chat = ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction,
    },
    history: history.map(msg => ({
      role: msg.role,
      parts: [{ text: msg.text }]
    }))
  });

  const lastUserMessage = history[history.length - 1];
  if (lastUserMessage.role !== 'user') {
    return "我準備好提供了協助。";
  }

  try {
    const pastHistory = history.slice(0, -1).map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
    }));

    const freshChat = ai.chats.create({
        model: 'gemini-3-pro-preview',
        config: { systemInstruction },
        history: pastHistory
    });

    const result = await freshChat.sendMessage({ message: lastUserMessage.text });
    return result.text || "我無法生成回應。";
  } catch (error) {
    console.error("Chat failed:", error);
    return "抱歉，我在回應時遇到了錯誤。";
  }
};