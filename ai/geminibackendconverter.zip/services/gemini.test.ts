import { convertFrontendToBackend, chatWithGemini } from './gemini';
import { GoogleGenAI } from '@google/genai';
import { Message } from '../types';

// Declare Jest globals to fix TS errors when types are missing
declare const jest: any;
declare const describe: any;
declare const it: any;
declare const expect: any;
declare const beforeEach: any;

// Mock the @google/genai library
jest.mock('@google/genai');

describe('Gemini Service', () => {
  let mockGenerateContent: any;
  let mockSendMessage: any;
  let mockCreateChat: any;

  beforeEach(() => {
    // Clear all mocks
    jest.clearAllMocks();

    // Setup mock functions
    mockGenerateContent = jest.fn();
    mockSendMessage = jest.fn();
    mockCreateChat = jest.fn(() => ({
      sendMessage: mockSendMessage,
    }));

    // Apply mocks to the class
    (GoogleGenAI as unknown as any).mockImplementation(() => ({
      models: {
        generateContent: mockGenerateContent,
      },
      chats: {
        create: mockCreateChat,
      },
    }));
  });

  describe('convertFrontendToBackend', () => {
    const mockFileContent = "console.log('hello world');";
    const mockFileName = "test-component.tsx";

    it('should correctly parse valid AI response with code blocks', async () => {
      const mockResponseText = `
        Here is your converted code:

        <BACKEND_APP_CODE>
        \`\`\`javascript
        const express = require('express');
        const app = express();
        \`\`\`
        </BACKEND_APP_CODE>

        <BACKEND_ROUTE_CODE>
        router.get('/test', (req, res) => res.send('ok'));
        </BACKEND_ROUTE_CODE>

        <FRONTEND_CODE>
        fetch('/api/v1/test');
        </FRONTEND_CODE>

        <README_CODE>
        # Documentation
        </README_CODE>
      `;

      mockGenerateContent.mockResolvedValue({
        text: mockResponseText
      });

      const result = await convertFrontendToBackend(mockFileContent, mockFileName);

      // Check if GenerateContent was called with correct model
      expect(mockGenerateContent).toHaveBeenCalledWith(expect.objectContaining({
        model: 'gemini-3-pro-preview',
      }));

      // Verify parsing logic (stripping markdown code blocks)
      expect(result.backendApp).toContain("const express = require('express');");
      expect(result.backendApp).not.toContain("```javascript");
      
      expect(result.backendRoutes).toBe("router.get('/test', (req, res) => res.send('ok'));");
      expect(result.frontend).toBe("fetch('/api/v1/test');");
      expect(result.readme).toBe("# Documentation");
    });

    it('should return error strings for missing tags', async () => {
      mockGenerateContent.mockResolvedValue({
        text: "This response is missing tags completely."
      });

      const result = await convertFrontendToBackend(mockFileContent, mockFileName);

      expect(result.backendApp).toContain('Error: Could not generate backend_app_code');
      expect(result.readme).toContain('Error: Could not generate readme_code');
    });

    it('should throw "無法使用 Gemini 轉換代碼。" on API failure', async () => {
      mockGenerateContent.mockRejectedValue(new Error('Network error'));

      await expect(convertFrontendToBackend(mockFileContent, mockFileName))
        .rejects
        .toThrow("無法使用 Gemini 轉換代碼。");
    });
  });

  describe('chatWithGemini', () => {
    const mockContext = "// Some code context";

    it('should send the user message to the chat model and return text', async () => {
      const history: Message[] = [
        { role: 'model', text: 'Hello', timestamp: 100 },
        { role: 'user', text: 'How do I run this?', timestamp: 101 }
      ];

      const mockResponseText = "You can run it using node server.js";
      mockSendMessage.mockResolvedValue({
        text: mockResponseText
      });

      const response = await chatWithGemini(history, mockContext);

      // It should create a chat with history (excluding last message)
      expect(mockCreateChat).toHaveBeenCalledWith(expect.objectContaining({
        history: expect.arrayContaining([
          expect.objectContaining({ role: 'model', parts: [{ text: 'Hello' }] })
        ])
      }));

      // It should send the last message
      expect(mockSendMessage).toHaveBeenCalledWith({ message: 'How do I run this?' });
      
      expect(response).toBe(mockResponseText);
    });

    it('should return "我準備好提供了協助。" if the last message is not from user', async () => {
       const history: Message[] = [
        { role: 'user', text: 'Hi', timestamp: 100 },
        { role: 'model', text: 'Hello back', timestamp: 101 }
      ];

      const response = await chatWithGemini(history, mockContext);

      expect(mockSendMessage).not.toHaveBeenCalled();
      expect(response).toBe("我準備好提供了協助。");
    });

    it('should return error message on API failure', async () => {
      const history: Message[] = [
        { role: 'user', text: 'Crash please', timestamp: 100 }
      ];

      mockSendMessage.mockRejectedValue(new Error('API Down'));

      const response = await chatWithGemini(history, mockContext);

      expect(response).toBe("抱歉，我在回應時遇到了錯誤。");
    });
  });
});