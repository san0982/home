# Gemini Backend Converter (Gemini 後端轉換器)

這是一個智能開發工具，旨在協助開發者將原本直接在前端調用 AI SDK 的程式碼，自動重構為安全、分層的 Node.js/Express 後端架構。本工具利用 Gemini 1.5 Pro 模型的強大能力來理解代碼邏輯並進行轉換。

## 核心功能

*   **自動重構**: 上傳前端檔案 (TS/JS)，自動生成 `server.js` (入口), `routes.js` (路由), 和重構後的客戶端代碼。
*   **智慧分析**: 使用 Google Gemini 3 Pro 模型理解原始代碼的意圖與 API 調用方式。
*   **即時預覽**: 內建語法高亮 (Syntax Highlighting) 的代碼檢視器，支援 TypeScript/JavaScript/Markdown。
*   **AI 助手**: 內建 ChatBot，可針對生成的代碼進行提問或尋求集成建議，上下文會自動帶入生成的代碼。
*   **彈性佈局**: 支援拖拉調整視窗大小 (Resizable Panels)，適應各種螢幕尺寸與閱讀需求。

## 專案結構與文件說明

本專案採用 React 19 + TypeScript 開發，主要文件用途如下：

### 1. 核心邏輯層
*   **`services/gemini.ts`**: 與 Google Gemini API 互動的核心服務。
    *   `convertFrontendToBackend`: 組裝 Prompt，將用戶上傳的前端代碼發送給 Gemini，並要求返回分割好的後端架構 (Server, Routes, Client, Readme)。
    *   `chatWithGemini`: 處理右下角 AI 助手的對話邏輯，讓 AI 扮演程式導師的角色。
*   **`App.tsx`**: 應用程式的主控制器。
    *   管理全局狀態 (上傳中、處理中、完成)。
    *   協調左右面板的顯示內容 (Source vs Output)。
    *   處理檔案上傳與轉換觸發。
*   **`types.ts`**: 定義 TypeScript 的介面與類型 (如 `AppState`, `FileData`, `Message`)，確保型別安全。

### 2. UI 元件 (Components)
*   **`components/CodeViewer.tsx`**: 強大的代碼檢視器。
    *   整合了 `Prism.js` 進行語法高亮 (Syntax Highlighting)。
    *   支援行號顯示與一鍵複製代碼。
*   **`components/ResizablePanel.tsx`**: 佈局管理器。
    *   實現了類似 IDE 的拖拉調整視窗功能。
    *   響應式設計：桌面版為左右分割，手機版自動切換為上下分割。
*   **`components/ChatBot.tsx`**: 懸浮式的 AI 聊天視窗。
    *   維護對話歷史。
    *   自動將當前生成的代碼作為 Context 傳送給 AI，以便回答相關問題。
*   **`components/Button.tsx`**: 封裝了 Loading 狀態與樣式的通用按鈕元件。

### 3. 入口與配置
*   **`index.html`**: 網頁入口文件。
    *   引入 Tailwind CSS (CDN)。
    *   引入 Prism.js 及其相關語言包 (用於語法高亮)。
    *   定義全局 CSS 變數與 Scrollbar 樣式。
*   **`index.tsx`**: React 的掛載點 (Entry Point)。
*   **`metadata.json`**: 定義應用程式的基本資訊與權限需求。

## 安裝與執行說明

### 前置需求
*   Node.js (建議 v18 或以上)
*   有效的 Google Gemini API Key

### 安裝步驟

1.  **安裝依賴**
    ```bash
    npm install
    ```

2.  **環境變數設定**
    本專案使用 `@google/genai` SDK，需要配置 API Key。
    通常在開發環境中，您可以建立 `.env` 檔案或直接在環境中設定：
    ```bash
    export API_KEY="your_gemini_api_key_here"
    ```

3.  **啟動開發伺服器**
    ```bash
    npm start
    # 或
    npm run dev
    ```

## 使用指南

1.  **上傳檔案**: 點擊介面左上角的上傳區塊，選擇原本包含 AI 邏輯的前端檔案 (`.ts`, `.tsx`, `.js`, `.jsx`)。
2.  **設定 API 前綴**: (可選) 設定後端 API 的路由前綴 (預設為 `/v1`)。
3.  **執行轉換**: 點擊 "Convert" 按鈕，等待 AI 處理 (約需 5-10 秒)。
4.  **檢視與導出**:
    *   **左側面板**: 切換查看原始代碼 (`original.ts`) 或新生成的客戶端代碼 (`client-xxx.ts`)。
    *   **右側面板**: 查看生成的後端代碼 (`server.js`, `routes.js`) 與說明文件 (`README.md`)。
5.  **調整視圖**: 拖曳中間的分隔線可自由調整左右區塊的大小。
6.  **AI 諮詢**: 若對生成的代碼有疑問，點擊右下角的 "詢問 AI" 按鈕進行對話，AI 已知曉生成的代碼內容。

## 技術棧

*   **Frontend**: React 19, TypeScript, Tailwind CSS
*   **AI Integration**: Google GenAI SDK (`@google/genai`)
*   **Utilities**: Lucide React (Icons), Prism.js (Syntax Highlighting)
