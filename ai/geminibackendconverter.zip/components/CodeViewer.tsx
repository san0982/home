import React, { useMemo } from 'react';
import { Copy, Check } from 'lucide-react';

interface CodeViewerProps {
  code: string;
  title?: string;
  className?: string;
  language?: string;
}

export const CodeViewer: React.FC<CodeViewerProps> = ({ code = "", title, className = '', language = 'javascript' }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Generate line numbers
  const safeCode = code || "";
  const lineNumbers = useMemo(() => safeCode.split('\n').map((_, i) => i + 1), [safeCode]);

  // Syntax Highlighting
  const highlightedCode = useMemo(() => {
    const Prism = (window as any).Prism;
    if (Prism && Prism.languages[language]) {
      return Prism.highlight(safeCode, Prism.languages[language], language);
    }
    // Fallback if Prism is not loaded or language not found
    return safeCode.replace(/[&<>"']/g, function(m: string) { 
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m] || m; 
    });
  }, [safeCode, language]);

  return (
    <div className={`flex flex-col h-full overflow-hidden bg-[#0d1117] ${className}`}>
      {/* Optional Header if title is provided */}
      {title && (
        <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-[#30363d]">
          <span className="text-xs font-mono text-slate-400">{title}</span>
        </div>
      )}
      
      <div className="relative flex-1 overflow-hidden group">
        {/* Copy Button - Absolute positioned in the corner */}
        <button 
          onClick={handleCopy}
          className="absolute top-4 right-6 p-2 bg-slate-800/80 backdrop-blur hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg transition-all opacity-0 group-hover:opacity-100 border border-slate-700 z-20"
          title="複製代碼"
        >
          {copied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
        </button>

        {/* Unified Scroll Container */}
        <div className="absolute inset-0 overflow-auto custom-scrollbar flex">
          
          {/* Sticky Line Numbers */}
          <div className="sticky left-0 z-10 flex flex-col py-4 px-2 text-right bg-[#0d1117] border-r border-[#30363d] select-none min-h-full">
             <pre className="text-xs font-mono leading-relaxed text-slate-600">
              {lineNumbers.map(n => (
                <div key={n} className="px-2">{n}</div>
              ))}
            </pre>
          </div>

          {/* Code Content */}
          <div className="flex-1 py-4 px-4 min-w-0">
             <pre className={`text-xs sm:text-sm font-mono leading-relaxed text-slate-300 whitespace-pre tab-4 language-${language}`}>
              <code dangerouslySetInnerHTML={{ __html: highlightedCode }} />
            </pre>
          </div>
          
        </div>
      </div>
    </div>
  );
};