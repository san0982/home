import React, { useState, useEffect, useRef } from 'react';

interface ResizablePanelProps {
  left: React.ReactNode;
  right: React.ReactNode;
}

export const ResizablePanel: React.FC<ResizablePanelProps> = ({ left, right }) => {
  const [isVertical, setIsVertical] = useState(false);
  const [split, setSplit] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  useEffect(() => {
    const checkLayout = () => {
      // Use 1024px to match standard lg breakpoint. 
      // < 1024px: Vertical Stack (Adjust Height)
      // >= 1024px: Horizontal Row (Adjust Width)
      setIsVertical(window.innerWidth < 1024);
    };
    
    checkLayout();
    window.addEventListener('resize', checkLayout);
    return () => window.removeEventListener('resize', checkLayout);
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current = true;
    
    // Add global listeners to handle dragging even if mouse leaves the handle
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    // UI Feedback
    document.body.style.cursor = isVertical ? 'row-resize' : 'col-resize';
    document.body.style.userSelect = 'none';
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging.current || !containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    let newSplit;
    
    if (isVertical) {
      // Calculate percentage based on Y offset for Vertical layout
      const offsetY = e.clientY - rect.top;
      newSplit = (offsetY / rect.height) * 100;
    } else {
      // Calculate percentage based on X offset for Horizontal layout
      const offsetX = e.clientX - rect.left;
      newSplit = (offsetX / rect.width) * 100;
    }

    // Clamp split between 15% and 85% to prevent panels from disappearing
    newSplit = Math.max(15, Math.min(85, newSplit));
    setSplit(newSplit);
  };

  const handleMouseUp = () => {
    isDragging.current = false;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
  };

  return (
    <div 
      ref={containerRef} 
      className={`flex ${isVertical ? 'flex-col' : 'flex-row'} w-full h-full overflow-hidden bg-[#0d1117] border border-[#30363d] rounded-xl shadow-2xl`}
    >
      {/* First Panel (Left or Top) */}
      <div style={{ flexBasis: `${split}%` }} className="relative min-h-0 min-w-0 flex flex-col transition-[flex-basis] duration-75 ease-out">
        {left}
      </div>
      
      {/* Drag Handle */}
      <div 
        className={`flex-none bg-[#0d1117] border-[#30363d] flex items-center justify-center z-10 transition-colors hover:bg-brand-500/10 group ${
          isVertical 
            ? 'h-3 w-full cursor-row-resize border-y' 
            : 'w-3 h-full cursor-col-resize border-x'
        }`}
        onMouseDown={handleMouseDown}
        title="Drag to resize"
      >
         <div className={`bg-[#30363d] group-hover:bg-brand-400 rounded-full transition-colors ${
            isVertical ? 'w-12 h-1' : 'w-1 h-12'
         }`} />
      </div>

      {/* Second Panel (Right or Bottom) */}
      <div style={{ flexBasis: `${100 - split}%` }} className="relative min-h-0 min-w-0 flex flex-col transition-[flex-basis] duration-75 ease-out">
        {right}
      </div>
    </div>
  );
};