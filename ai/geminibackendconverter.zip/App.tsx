import React, { useState, useRef } from 'react';
import { Upload, FileCode, ArrowRight, Server, RefreshCcw, Zap, CheckCircle2, Globe, FileJson, Settings2, FileText, Play, Code, AlertCircle } from 'lucide-react';
import { AppState, FileData, Tab } from './types';
import { convertFrontendToBackend } from './services/gemini';
import { Button } from './components/Button';
import { CodeViewer } from './components/CodeViewer';
import { ChatBot } from './components/ChatBot';
import { ResizablePanel } from './components/ResizablePanel';

export default function App() {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [inputFile, setInputFile] = useState<FileData | null>(null);
  const [apiPrefix, setApiPrefix] = useState<string>("/v1");
  
  // Code States
  const [backendAppCode, setBackendAppCode] = useState<string>("");
  const [backendRoutesCode, setBackendRoutesCode] = useState<string>("");
  const [readmeCode, setReadmeCode] = useState<string>("");
  const [frontendClientCode, setFrontendClientCode] = useState<string>("");
  
  // Panel Modes
  const [leftPanelMode, setLeftPanelMode] = useState<'ORIGINAL' | 'NEW_CLIENT'>('ORIGINAL');
  const [rightPanelMode, setRightPanelMode] = useState<'SERVER' | 'ROUTES' | 'README'>('SERVER');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.match(/\.(ts|tsx|js|jsx)$/)) {
      alert("請上傳 TypeScript 或 JavaScript 文件 (.ts, .tsx, .js, .jsx)。");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setInputFile({ name: file.name, content });
      setAppState(AppState.IDLE); 
      setLeftPanelMode('ORIGINAL');
    };
    reader.readAsText(file);
  };

  const handleConvert = async () => {
    if (!inputFile) return;
    setAppState(AppState.PROCESSING);

    try {
      const { backendApp, backendRoutes, frontend, readme } = await convertFrontendToBackend(inputFile.content, inputFile.name, apiPrefix);
      
      // Store results
      setBackendAppCode(backendApp);
      setBackendRoutesCode(backendRoutes);
      setFrontendClientCode(frontend);
      setReadmeCode(readme);
      
      setAppState(AppState.COMPLETE);
      
      // UI defaults after conversion
      setLeftPanelMode('NEW_CLIENT'); 
      setRightPanelMode('SERVER'); // Default to showing Server code
    } catch (error) {
      console.error(error);
      setAppState(AppState.ERROR);
    }
  };

  const reset = () => {
    setAppState(AppState.IDLE);
    setInputFile(null);
    setBackendAppCode("");
    setBackendRoutesCode("");
    setFrontendClientCode("");
    setReadmeCode("");
    setApiPrefix("/v1");
    setLeftPanelMode('ORIGINAL');
    setRightPanelMode('SERVER');
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // Helper component for Tabs
  const TabButton = ({ active, onClick, icon: Icon, label }: { active: boolean, onClick: () => void, icon: any, label: string }) => (
    <button
      onClick={onClick}
      className={`
        flex items-center gap-2 px-4 py-2.5 text-xs font-medium transition-all border-r border-[#30363d] whitespace-nowrap
        ${active 
          ? 'bg-[#0d1117] text-brand-400 border-t-2 border-t-brand-500' 
          : 'bg-[#161b22] text-slate-400 hover:bg-[#1c2128] hover:text-slate-200 border-t-2 border-t-transparent'
        }
      `}
    >
      <Icon size={14} className={active ? "text-brand-400" : "text-slate-500"} />
      {label}
    </button>
  );

  const getCurrentRightPanelCode = () => {
    switch (rightPanelMode) {
      case 'SERVER': return backendAppCode;
      case 'ROUTES': return backendRoutesCode;
      case 'README': return readmeCode;
      default: return "";
    }
  };

  const rightCode = getCurrentRightPanelCode();
  
  // Helper to detect language
  const getLanguage = (fileName: string) => {
    if (fileName.endsWith('.tsx') || fileName.endsWith('.ts')) return 'typescript';
    if (fileName.endsWith('.jsx') || fileName.endsWith('.js')) return 'javascript';
    if (fileName.endsWith('.json')) return 'json';
    if (fileName.endsWith('.md')) return 'markdown';
    return 'javascript';
  };

  const getLeftLanguage = () => {
    if (!inputFile) return 'typescript';
    return getLanguage(inputFile.name);
  };

  const getRightLanguage = () => {
    switch(rightPanelMode) {
      case 'SERVER': return 'javascript';
      case 'ROUTES': return 'javascript';
      case 'README': return 'markdown';
      default: return 'javascript';
    }
  };

  return (
    <div className="min-h-screen bg-[#0d1117] text-slate-200 font-sans selection:bg-brand-500/30 flex flex-col">
      
      {/* Background Ambience */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-brand-900/10 rounded-full blur-[150px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-purple-900/10 rounded-full blur-[150px]" />
      </div>

      <div className="relative max-w-[1600px] mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex flex-col h-screen max-h-screen">
        
        {/* Header */}
        <header className="flex items-center justify-between mb-6 flex-none">
          <div className="flex items-center gap-3">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-brand-600 to-purple-600 rounded-lg blur opacity-40 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative p-2 bg-[#0d1117] ring-1 ring-slate-800 rounded-lg">
                <Server className="text-brand-400" size={24} />
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                Gemini Bridge <span className="text-[10px] bg-brand-500/10 text-brand-400 border border-brand-500/20 px-1.5 py-0.5 rounded uppercase tracking-wider">Beta</span>
              </h1>
              <p className="text-xs text-slate-500 font-mono">Frontend to Backend Converter</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
             <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/50 border border-slate-800 text-slate-400 text-xs font-mono">
                <Zap size={12} className="text-yellow-500" />
                <span>Model: gemini-3-pro</span>
             </div>
          </div>
        </header>

        {/* Main Workspace */}
        <main className="flex-1 flex flex-col min-h-0 gap-6">
          
          {/* Configuration Card */}
          <div className="flex-none bg-[#161b22] border border-[#30363d] rounded-xl p-1 shadow-xl">
            <div className="flex flex-col md:flex-row items-center gap-2">
              
              {/* File Input */}
              <div 
                className="flex-1 w-full md:w-auto flex items-center gap-3 px-4 py-3 bg-[#0d1117] hover:bg-[#13171f] border border-[#30363d] border-dashed rounded-lg cursor-pointer transition-colors group relative overflow-hidden"
                onClick={() => fileInputRef.current?.click()}
              >
                <div className="p-2 bg-slate-800 rounded-md group-hover:bg-slate-700 transition-colors">
                  <FileCode size={20} className="text-brand-400" />
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-slate-200">
                    {inputFile ? inputFile.name : "Upload Service File"}
                  </span>
                  <span className="text-xs text-slate-500">
                    {inputFile ? "Ready to convert" : "Supports .ts, .tsx, .js, .jsx"}
                  </span>
                </div>
                {appState === AppState.COMPLETE && (
                  <div className="absolute right-4 top-1/2 -translate-y-1/2">
                    <CheckCircle2 className="text-green-500" size={20} />
                  </div>
                )}
                <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} accept=".ts,.tsx,.js,.jsx" />
              </div>

              {/* Settings & Action */}
              <div className={`flex items-center gap-2 w-full md:w-auto transition-all duration-500 ${inputFile ? 'opacity-100 translate-x-0' : 'opacity-50 grayscale pointer-events-none'}`}>
                 <div className="h-8 w-px bg-[#30363d] hidden md:block mx-2" />
                 
                 <div className="flex items-center gap-2 px-3 py-2 bg-[#0d1117] border border-[#30363d] rounded-lg">
                    <span className="text-xs text-slate-500 font-mono">PREFIX</span>
                    <input 
                      type="text" 
                      value={apiPrefix}
                      onChange={(e) => setApiPrefix(e.target.value)}
                      className="bg-transparent border-none p-0 text-sm text-brand-300 w-16 font-mono focus:ring-0 placeholder-slate-700"
                    />
                 </div>

                 <Button 
                   onClick={handleConvert} 
                   disabled={appState === AppState.PROCESSING || !inputFile}
                   isLoading={appState === AppState.PROCESSING}
                   className="w-full md:w-auto"
                 >
                   <span className="mr-2">Convert</span>
                   <Play size={14} fill="currentColor" />
                 </Button>

                 {appState === AppState.COMPLETE && (
                    <button 
                      onClick={reset}
                      className="p-3 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors border border-transparent hover:border-[#30363d]"
                      title="Reset"
                    >
                      <RefreshCcw size={18} />
                    </button>
                 )}
              </div>
            </div>
          </div>

          {/* IDE Area - Resizable Split View */}
          <div className="flex-1 min-h-0">
            <ResizablePanel
              left={
                <div className="flex flex-col h-full bg-[#0d1117] overflow-hidden">
                  {/* Tabs */}
                  <div className="flex items-center bg-[#161b22] border-b border-[#30363d] overflow-x-auto no-scrollbar flex-none">
                     <div className="px-4 py-2 text-xs font-bold text-slate-500 tracking-wider">SOURCE</div>
                     
                     <TabButton 
                        active={leftPanelMode === 'ORIGINAL'} 
                        onClick={() => setLeftPanelMode('ORIGINAL')} 
                        icon={FileCode} 
                        label={inputFile ? inputFile.name : 'original.ts'} 
                     />
                     
                     {appState === AppState.COMPLETE && (
                       <TabButton 
                          active={leftPanelMode === 'NEW_CLIENT'} 
                          onClick={() => setLeftPanelMode('NEW_CLIENT')} 
                          icon={Code} 
                          label={`client-${inputFile?.name}`} 
                       />
                     )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 relative">
                    {inputFile ? (
                        <CodeViewer 
                          code={leftPanelMode === 'NEW_CLIENT' && frontendClientCode ? frontendClientCode : inputFile.content} 
                          language={getLeftLanguage()}
                          className="absolute inset-0"
                        />
                    ) : (
                      <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-600 bg-[#0d1117]">
                        <div className="w-16 h-16 rounded-2xl bg-[#161b22] border border-[#30363d] flex items-center justify-center mb-4 rotate-3">
                           <Upload size={32} className="opacity-50" />
                        </div>
                        <p className="text-sm font-medium">Waiting for file upload...</p>
                      </div>
                    )}
                  </div>
                </div>
              }
              right={
                <div className="flex flex-col h-full bg-[#0d1117] overflow-hidden">
                   {/* Tabs */}
                  <div className="flex items-center bg-[#161b22] border-b border-[#30363d] overflow-x-auto no-scrollbar flex-none">
                     <div className="px-4 py-2 text-xs font-bold text-brand-600/70 tracking-wider">OUTPUT</div>
                     
                     <TabButton 
                        active={rightPanelMode === 'SERVER'} 
                        onClick={() => setRightPanelMode('SERVER')} 
                        icon={Settings2} 
                        label="server.js" 
                     />
                     <TabButton 
                        active={rightPanelMode === 'ROUTES'} 
                        onClick={() => setRightPanelMode('ROUTES')} 
                        icon={FileJson} 
                        label="routes.js" 
                     />
                     <TabButton 
                        active={rightPanelMode === 'README'} 
                        onClick={() => setRightPanelMode('README')} 
                        icon={FileText} 
                        label="README.md" 
                     />
                  </div>

                  {/* Content */}
                  <div className="flex-1 relative">
                    {appState === AppState.COMPLETE || backendAppCode ? (
                       rightCode ? (
                         <CodeViewer 
                            code={rightCode} 
                            language={getRightLanguage()}
                            className="absolute inset-0"
                         />
                       ) : (
                         <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 bg-[#0d1117] p-8">
                            <AlertCircle size={32} className="mb-2 text-slate-600" />
                            <p className="text-sm">此區塊無內容或生成失敗。</p>
                         </div>
                       )
                    ) : (
                      <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-600 bg-[#0d1117] p-8">
                         {appState === AppState.PROCESSING ? (
                           <div className="flex flex-col items-center">
                              <div className="relative">
                                <div className="w-16 h-16 rounded-full border-4 border-[#30363d]"></div>
                                <div className="absolute top-0 left-0 w-16 h-16 rounded-full border-4 border-brand-500 border-t-transparent animate-spin"></div>
                              </div>
                              <p className="mt-4 text-brand-400 font-mono text-sm animate-pulse">Generating Architecture...</p>
                           </div>
                         ) : (
                           <div className="flex flex-col items-center opacity-40">
                              <div className="w-16 h-16 rounded-2xl bg-[#161b22] border border-[#30363d] flex items-center justify-center mb-4 -rotate-3">
                                 <Server size={32} />
                              </div>
                              <p className="text-sm font-medium">Generated backend code will appear here</p>
                           </div>
                         )}
                      </div>
                    )}
                  </div>
                </div>
              }
            />
          </div>

        </main>
      </div>
      
      {/* Floating Chat Bot */}
      {appState === AppState.COMPLETE && (
        <ChatBot codeContext={`// SERVER.JS:\n${backendAppCode}\n\n// ROUTES.JS:\n${backendRoutesCode}\n\n// FRONTEND CLIENT CODE:\n${frontendClientCode}\n\n// README:\n${readmeCode}`} />
      )}
    </div>
  );
}