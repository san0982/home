export enum AppState {
  IDLE = 'IDLE',
  UPLOADING = 'UPLOADING',
  PROCESSING = 'PROCESSING',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR'
}

export interface FileData {
  name: string;
  content: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export enum Tab {
  FRONTEND = 'FRONTEND',
  BACKEND = 'BACKEND',
}
