
export type Sender = 'user' | 'ai';

export enum MessageType {
  TEXT = 'TEXT',
  TABLE_SELECTION = 'TABLE_SELECTION',
  COLUMN_SELECTION = 'COLUMN_SELECTION',
  DATA_PREVIEW = 'DATA_PREVIEW',
  DOWNLOAD_ACTION = 'DOWNLOAD_ACTION',
  ERROR = 'ERROR'
}

export interface DatabaseConnection {
  id: string;
  name: string; 
  type: string; 
  configSummary: string;
}

export interface TableSchema {
  name: string;
  description: string;
  columns: string[];
  connectionId: string;
  requiresWhere: boolean;
}

export interface JoinCondition {
  leftTable: string;
  leftColumn: string;
  rightTable: string;
  rightColumn: string;
}

export interface ChatMessage {
  id: string;
  sender: Sender;
  type: MessageType;
  content: string; 
  
  // Optional payloads
  suggestedTables?: string[]; 
  availableColumns?: { tableName: string; columns: string[] }[];
  previewData?: {
    tableName: string; // Or "Joined Result"
    rows: any[];
    sql?: string; // New: SQL query string
  };
  downloadData?: {
    tableName: string;
    totalRows: number;
  };
}

export type ConversationState = 
  | 'idle' 
  | 'analyzing' 
  | 'selecting_tables'      
  | 'configuring_joins'     
  | 'selecting_columns'     
  | 'fetching_preview' 
  | 'waiting_preview_confirm' 
  | 'generating_download';
