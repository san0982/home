
import { GoogleGenAI, Type } from "@google/genai";
import { DB_SCHEMA, DB_CONNECTIONS } from "./mockData";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Analyzes the user's natural language query against the mock database schema
 * to determine which tables are most relevant.
 */
export const identifyRelevantTables = async (userQuery: string): Promise<string[]> => {
  // Build a rich schema description including connection info and constraints
  const schemaDescription = DB_SCHEMA.map(t => {
    const conn = DB_CONNECTIONS.find(c => c.id === t.connectionId);
    const connInfo = conn ? `[Connection: ${conn.name}]` : '';
    const constraint = t.requiresWhere ? '[Constraint: Requires WHERE clause]' : '[Constraint: None]';
    return `Table: ${t.name} ${connInfo} ${constraint}\nDescription: ${t.description}\nColumns: ${t.columns.join(', ')}`;
  }).join('\n\n');

  const systemInstruction = `
    You are an expert Data Engineer. 
    Your task is to map a user's natural language request (in Traditional Chinese) to the most relevant database table from the provided schema.
    
    Database Schema Configuration:
    ${schemaDescription}

    Rules:
    1. Identify the most relevant table(s). If the user asks for a join or cross-reference, return multiple tables.
    2. If the request is ambiguous, pick the most likely candidates.
    3. Return table names as a string list.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview', // Using Pro for complex reasoning/schema mapping
      contents: userQuery,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tables: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) return [];
    
    const result = JSON.parse(jsonText);
    return result.tables || [];
  } catch (error) {
    console.error("Gemini API Error:", error);
    return [];
  }
};

export const generateFriendlyResponse = async (userQuery: string): Promise<string> => {
   try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `User said: "${userQuery}". Provide a very brief, friendly, 1-sentence acknowledgement in Traditional Chinese (繁體中文) that you are looking into their data request.`,
    });
    return response.text || "正在為您查詢資料庫...";
  } catch (e) {
    return "讓我為您確認一下。";
  }
}

// Helper to get columns for multiple tables for UI selection
export const getTableColumns = (tableNames: string[]) => {
    return tableNames.map(name => {
        const schema = DB_SCHEMA.find(t => t.name === name);
        return {
            tableName: name,
            columns: schema ? schema.columns : []
        };
    });
};
