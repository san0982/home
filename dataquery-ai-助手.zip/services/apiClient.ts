
// 這是前端用來呼叫我們剛建立的 Express 後端的 Service
import { JoinCondition } from '../types';

const API_BASE_URL = 'http://localhost:3001/api';

export const apiClient = {
  // 1. 呼叫後端分析
  analyzeQuery: async (query: string): Promise<string[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      });
      if (!res.ok) throw new Error('Server analysis failed');
      const data = await res.json();
      return data.tables || [];
    } catch (e) {
      console.error("API Error:", e);
      throw e;
    }
  },

  // 2. 呼叫後端預覽資料
  fetchPreview: async (tableName: string): Promise<{ data: any[], sql?: string }> => {
    try {
      const res = await fetch(`${API_BASE_URL}/preview`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableName })
      });
      if (!res.ok) throw new Error('Server preview failed');
      const response = await res.json();
      return { data: response.data || [], sql: response.sql };
    } catch (e) {
      console.error("API Error:", e);
      throw e;
    }
  },

  // New: 呼叫後端 Join 預覽
  fetchJoinPreview: async (tables: string[], selectedColumns: string[], joinConditions: JoinCondition[] = []): Promise<{ data: any[], sql?: string }> => {
    try {
      const res = await fetch(`${API_BASE_URL}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tables, selectedColumns, joinConditions })
      });
      if (!res.ok) throw new Error('Server join failed');
      const response = await res.json();
      return { data: response.data || [], sql: response.sql };
    } catch (e) {
      console.error("API Error:", e);
      throw e;
    }
  },

  // 3. 呼叫後端下載資料
  fetchFullData: async (tableName: string): Promise<any[]> => {
    try {
      const res = await fetch(`${API_BASE_URL}/download`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableName })
      });
      if (!res.ok) throw new Error('Server download failed');
      const data = await res.json();
      return data.data || [];
    } catch (e) {
      console.error("API Error:", e);
      throw e;
    }
  }
};
