
import { TableSchema, DatabaseConnection, JoinCondition } from '../types';

// 定義多個資料庫連線 (根據使用者需求設定)
export const DB_CONNECTIONS: DatabaseConnection[] = [
  { 
    id: 'conn_oracle_local', 
    name: 'Oracle Dev (Scott)', 
    type: 'Oracle',
    configSummary: 'User: scott | Connect: localhost:1521/orclpdb1'
  },
  { 
    id: 'conn_pg_local', 
    name: 'Postgres Local (MyDb)', 
    type: 'PostgreSQL',
    configSummary: 'User: myuser | Host: localhost:5432 | DB: mydb'
  }
];

// 定義資料表 Schema，包含連線資訊與限制條件
export const DB_SCHEMA: TableSchema[] = [
  {
    name: 'mytest1',
    description: '這是一個測試資料表',
    columns: ['id', 'test_name', 'test_value', 'owner', 'created_at', 'memo'], 
    connectionId: 'conn_oracle_local',
    requiresWhere: false
  },
  {
    name: 'project_1',
    description: '這是記錄個人專案表',
    columns: ['project_id', 'project_name', 'owner', 'start_date', 'status', 'budget'],
    connectionId: 'conn_pg_local',
    requiresWhere: false
  },
  // New Table 1: HR System
  {
    name: 'employees',
    description: '公司員工基本資料表',
    columns: ['emp_id', 'emp_name', 'dept_id', 'title', 'hire_date', 'salary', 'email'],
    connectionId: 'conn_oracle_local',
    requiresWhere: false
  },
  // New Table 2: Sales System
  {
    name: 'sales_orders',
    description: '產品銷售訂單紀錄',
    columns: ['order_id', 'customer_name', 'product_name', 'amount', 'order_date', 'region', 'sales_rep'],
    connectionId: 'conn_pg_local',
    requiresWhere: true // Set to true to test UI warning
  },
  // New Table 3: Warehouse System
  {
    name: 'inventory_items',
    description: '倉庫庫存商品清單',
    columns: ['sku', 'product_name', 'category', 'quantity_on_hand', 'warehouse_loc', 'last_restock_date'],
    connectionId: 'conn_pg_local',
    requiresWhere: false
  },
  // New Table 4: CRM Support
  {
    name: 'customer_support',
    description: '客戶服務工單紀錄',
    columns: ['ticket_id', 'customer_email', 'issue_type', 'priority', 'status', 'created_at', 'assigned_emp_id'],
    connectionId: 'conn_oracle_local',
    requiresWhere: false
  }
];

// Helper to generate fake data
const generateRandomData = (table: string, count: number) => {
  const data = [];
  const owners = ['MyUser', 'Alex', 'Sarah', 'John', 'Emily'];
  const depts = ['IT', 'HR', 'Sales', 'Marketing', 'Finance'];
  const products = ['Laptop Pro', 'Wireless Mouse', '4K Monitor', 'Mech Keyboard', 'USB-C Hub'];
  const regions = ['North', 'South', 'East', 'West'];

  for (let i = 0; i < count; i++) {
    const randomOwner = owners[Math.floor(Math.random() * owners.length)];

    switch (table) {
      case 'mytest1':
        data.push({
          id: i + 1,
          test_name: `Test_Case_${String.fromCharCode(65 + (i % 26))}`,
          test_value: Math.floor(Math.random() * 1000),
          owner: randomOwner, 
          created_at: new Date().toISOString(),
          memo: ['Initial load', 'Retry', 'Success', 'Pending'][Math.floor(Math.random() * 4)]
        });
        break;
      case 'project_1':
        data.push({
          project_id: `P-${2024001 + i}`,
          project_name: ['網站改版', 'API 整合', '資料庫遷移', 'App 開發', '資安稽核'][Math.floor(Math.random() * 5)],
          owner: randomOwner, 
          start_date: new Date(Date.now() - Math.floor(Math.random() * 10000000000)).toISOString().split('T')[0],
          status: ['進行中', '已結案', '暫停'][Math.floor(Math.random() * 3)],
          budget: Math.floor(Math.random() * 500000)
        });
        break;
      case 'employees':
        data.push({
          emp_id: `E${1000 + i}`,
          emp_name: randomOwner,
          dept_id: depts[Math.floor(Math.random() * depts.length)],
          title: ['Engineer', 'Manager', 'Analyst', 'Specialist'][Math.floor(Math.random() * 4)],
          hire_date: new Date(Date.now() - Math.floor(Math.random() * 300000000000)).toISOString().split('T')[0],
          salary: 40000 + Math.floor(Math.random() * 60000),
          email: `${randomOwner.toLowerCase()}@company.com`
        });
        break;
      case 'sales_orders':
        data.push({
          order_id: `ORD-${20240001 + i}`,
          customer_name: `Customer_${String.fromCharCode(65 + (i % 5))}`,
          product_name: products[Math.floor(Math.random() * products.length)],
          amount: 1000 + Math.floor(Math.random() * 50000),
          order_date: new Date().toISOString().split('T')[0],
          region: regions[Math.floor(Math.random() * regions.length)],
          sales_rep: randomOwner // Key for join
        });
        break;
      case 'inventory_items':
        const prod = products[i % products.length];
        data.push({
          sku: `SKU-${100 + i}`,
          product_name: prod, // Key for join
          category: 'Electronics',
          quantity_on_hand: Math.floor(Math.random() * 500),
          warehouse_loc: `Zone-${String.fromCharCode(65 + (i % 3))}`,
          last_restock_date: new Date().toISOString().split('T')[0]
        });
        break;
      case 'customer_support':
        data.push({
          ticket_id: `TKT-${5000 + i}`,
          customer_email: `user${i}@gmail.com`,
          issue_type: ['Login Issue', 'Payment Fail', 'Bug Report', 'Feature Req'][Math.floor(Math.random() * 4)],
          priority: ['High', 'Medium', 'Low'][Math.floor(Math.random() * 3)],
          status: ['Open', 'In Progress', 'Resolved'][Math.floor(Math.random() * 3)],
          created_at: new Date().toISOString(),
          assigned_emp_id: `E${1000 + (i % 5)}` // Key for join with employees
        });
        break;
      default:
        data.push({ id: i, info: '範例資料' });
    }
  }
  return data;
};

export const fetchPreviewData = async (tableName: string) => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));
  const data = generateRandomData(tableName, 10);
  const sql = `SELECT * FROM ${tableName} FETCH NEXT 10 ROWS ONLY`;
  return { data, sql };
};

export const fetchFullData = async (tableName: string) => {
  // Simulate network delay for larger dataset
  await new Promise(resolve => setTimeout(resolve, 1500));
  return generateRandomData(tableName, 50); 
};

// Mock Join functionality with Support for Explicit Conditions
export const fetchJoinData = async (tables: string[], selectedColumns: string[], joinConditions: JoinCondition[] = []) => {
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Generate data for all tables
    const tableData: Record<string, any[]> = {};
    for (const t of tables) {
        tableData[t] = generateRandomData(t, 20);
    }

    const primaryTable = tables[0];
    
    // Perform simulated join
    const joinedRows = tableData[primaryTable].map((row1, idx) => {
        let joinedRow = { ...row1 };
        
        // Loop through other tables and try to merge
        for (let i = 1; i < tables.length; i++) {
            const targetTable = tables[i];
            
            // Find a condition linking to this table
            let match = null;
            
            if (joinConditions.length > 0) {
                // Find a condition involving targetTable and any already processed table (simplified: just row1 for now)
                // In a real generic join, we'd need to check against the accumulated `joinedRow`.
                
                const condition = joinConditions.find(c => 
                   (c.leftTable === targetTable && c.rightTable === primaryTable) ||
                   (c.rightTable === targetTable && c.leftTable === primaryTable)
                );
                
                if (condition) {
                   const isLeft = condition.leftTable === targetTable;
                   const targetCol = isLeft ? condition.leftColumn : condition.rightColumn;
                   const sourceCol = isLeft ? condition.rightColumn : condition.leftColumn;
                   
                   match = tableData[targetTable].find(r => r[targetCol] === row1[sourceCol]);
                }
            } 
            
            if (!match && joinConditions.length === 0) {
                 // Fallback to naive auto-matching if no conditions provided
                 if (row1.owner && tableData[targetTable].find(r => r.owner === row1.owner)) {
                      match = tableData[targetTable].find(r => r.owner === row1.owner);
                 } else if (row1.product_name && tableData[targetTable].find(r => r.product_name === row1.product_name)) {
                      match = tableData[targetTable].find(r => r.product_name === row1.product_name);
                 } else if (row1.emp_id && tableData[targetTable].find(r => r.assigned_emp_id === row1.emp_id)) {
                      match = tableData[targetTable].find(r => r.assigned_emp_id === row1.emp_id);
                 } else if (row1.sales_rep && tableData[targetTable].find(r => r.emp_name === row1.sales_rep)) {
                      match = tableData[targetTable].find(r => r.emp_name === row1.sales_rep);
                 } else {
                      // Fallback: match by index
                      match = tableData[targetTable][idx];
                 }
            }

            if (match) {
                const prefixedMatch: any = {};
                Object.keys(match).forEach(k => {
                    prefixedMatch[`${targetTable}.${k}`] = match[k];
                });
                joinedRow = { ...joinedRow, ...prefixedMatch };
            }
        }
        return joinedRow;
    });

    // Filter columns based on selection
    const finalRows = joinedRows.map(row => {
        const filtered: any = {};
        if (!selectedColumns || selectedColumns.length === 0) return row;

        selectedColumns.forEach(colKey => {
            const [tbl, col] = colKey.includes('.') ? colKey.split('.') : [null, colKey];
            
            if (tbl && tbl === primaryTable) {
                 if (row[col] !== undefined) filtered[colKey] = row[col];
            } else if (tbl) {
                 if (row[`${tbl}.${col}`] !== undefined) filtered[colKey] = row[`${tbl}.${col}`];
            } else {
                 if (row[colKey] !== undefined) filtered[colKey] = row[colKey];
            }
        });
        return filtered;
    });

    // Generate Mock SQL
    let mockSql = `SELECT ${selectedColumns.length > 0 ? selectedColumns.join(', ') : '*'} \nFROM ${tables[0]}`;
    if (joinConditions.length > 0) {
        joinConditions.forEach(c => {
             // simplified logic for mock sql display
             const otherTable = c.leftTable === tables[0] ? c.rightTable : c.leftTable;
             const myCol = c.leftTable === tables[0] ? c.leftColumn : c.rightColumn;
             const otherCol = c.leftTable === tables[0] ? c.rightColumn : c.leftColumn;
             mockSql += `\nLEFT JOIN ${otherTable} ON ${tables[0]}.${myCol} = ${otherTable}.${otherCol}`;
        });
    } else {
         for(let i=1; i<tables.length; i++) {
             mockSql += `\nCROSS JOIN ${tables[i]}`;
         }
    }
    mockSql += `\nFETCH NEXT 10 ROWS ONLY`;

    return { data: finalRows.slice(0, 10), sql: mockSql };
};

export const getTableDetails = (tableName: string) => {
    return DB_SCHEMA.find(t => t.name === tableName);
};

export const getConnectionDetails = (connectionId: string) => {
    return DB_CONNECTIONS.find(c => c.id === connectionId);
};
