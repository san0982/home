# DataQuery AI 助手 - 專案結構說明文件

這是一個結合 AI 對話介面與資料庫查詢功能的應用程式。支援 **純前端模擬模式 (Mock)** 與 **後端真實連線模式 (Real Server)**。

以下是專案中所有檔案的功能詳細說明。

## 📁 根目錄 (Root)

| 檔案名稱 | 功能說明 |
| :--- | :--- |
| **index.html** | 應用程式的進入點 (Entry Point)。引入了 Tailwind CSS、字型以及 Import Maps (管理 React 與 Google GenAI SDK 的依賴)。 |
| **index.tsx** | React 的掛載點。負責將 `App` 元件渲染到 DOM 上。 |
| **App.tsx** | 應用程式的主版面配置，包含了主要元件 `ChatInterface`。 |
| **types.ts** | 定義全域使用的 TypeScript 型別介面。包含 `ChatMessage` (對話訊息), `TableSchema` (資料表定義), `JoinCondition` (關聯條件) 等核心結構。 |
| **metadata.json** | 應用程式的元數據設定，包含 App 名稱、描述與權限設定。 |

---

## 📁 Components (UI 元件)

| 檔案名稱 | 功能說明 |
| :--- | :--- |
| **components/ChatInterface.tsx** | **核心 UI 元件**。處理所有使用者互動邏輯，包含：<br>1. 聊天視窗與訊息渲染。<br>2. 資料表選擇器 (支援多選)。<br>3. Join 設定介面 (指定關聯鍵)。<br>4. 欄位勾選介面。<br>5. 資料預覽與 SQL 顯示。<br>6. 切換「模擬/後端」模式的開關。 |

---

## 📁 Services (前端邏輯服務)

這些檔案運行於瀏覽器端，負責處理資料邏輯與 API 呼叫。

| 檔案名稱 | 功能說明 |
| :--- | :--- |
| **services/mockData.ts** | **模擬資料庫層**。在不啟動後端時提供服務。<br>1. 定義 `DB_SCHEMA` 與 `DB_CONNECTIONS`。<br>2. `generateRandomData`: 產生假資料。<br>3. `fetchJoinData`: 使用 JavaScript 模擬 SQL Join 邏輯。 |
| **services/geminiService.ts** | **前端 AI 服務**。直接從瀏覽器呼叫 Gemini API。<br>1. `identifyRelevantTables`: 分析使用者語意並推薦資料表。<br>2. `generateFriendlyResponse`: 產生親切的對話回應。 |
| **services/apiClient.ts** | **API 客戶端**。負責與本地後端 (`localhost:3001`) 溝通。<br>封裝了 `analyze`, `preview`, `join`, `download` 等 API 請求。 |

---

## 📁 Server (後端伺服器 - Node.js)

這些檔案需在 Node.js 環境下執行 (需執行 `npm install` 與 `node server/index.js`)，用於連接真實的 Oracle/PostgreSQL 資料庫。

| 檔案名稱 | 功能說明 |
| :--- | :--- |
| **server/index.js** | **Express 伺服器入口**。定義 API路由 (`/api/analyze`, `/api/join` 等)。負責接收前端請求並協調 AI 與資料庫查詢。 |
| **server/config.js** | **後端設定檔**。讀取 `.env` 環境變數 (資料庫帳密、API Key)，並定義後端視角的 `TABLE_MAPPINGS` (資料表映射)。 |
| **server/db.js** | **資料庫連線層**。實作 `oracledb` 與 `pg` (PostgreSQL) 的連線邏輯。包含 `executeRawQuery` 用於執行 AI 生成的 SQL。 |
| **server/gemini.js** | **後端 AI 服務**。當前端傳來 Join 請求但未指定條件時，由此處呼叫 Gemini 生成 SQL Join 語法。 |

---

## 🚀 快速啟動指南

### 1. 純前端模式 (預設)
直接開啟網頁即可使用。系統會使用 `services/mockData.ts` 內的假資料與前端 Gemini API 進行展示。

### 2. 後端模式 (真實連線)
若要連接真實資料庫，請執行以下步驟：

1. 進入 `server` 資料夾。
2. 建立 `.env` 檔案並填入 `API_KEY`, `ORACLE_USER`, `PG_USER` 等資訊。
3. 安裝依賴：
   ```bash
   npm install express cors dotenv pg oracledb @google/genai
   ```
4. 啟動伺服器：
   ```bash
   node index.js
   ```
5. 在網頁右上角切換開關至 **「後端」**。
