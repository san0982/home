
const { GoogleGenAI, Type } = require("@google/genai");
const { TABLE_MAPPINGS, DB_CONFIG } = require('./config');

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

async function identifyRelevantTables(userQuery) {
  // 建構 Schema 描述給 AI
  const schemaDescription = TABLE_MAPPINGS.map(t => {
    const dbInfo = `[DB: ${t.dbType}]`;
    const constraint = t.requiresWhere ? '[Constraint: Requires WHERE clause]' : '[Constraint: None]';
    return `Table: ${t.name} ${dbInfo} ${constraint}\nDescription: ${t.description}\nColumns: ${t.columns.join(', ')}`;
  }).join('\n\n');

  const systemInstruction = `
    You are an expert Data Engineer. 
    Your task is to map a user's natural language request (in Traditional Chinese) to the most relevant database table from the provided schema.
    
    Database Schema Configuration:
    ${schemaDescription}

    Rules:
    1. Identify the most relevant table(s). If the request implies joining data, return multiple tables.
    2. If the request is ambiguous, pick the most likely candidate.
    3. Return ONLY the table name as a string in the list.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: userQuery,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tables: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          }
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) return [];
    const result = JSON.parse(jsonText);
    return result.tables || [];
  } catch (error) {
    console.error("Gemini API Error:", error);
    return [];
  }
}

// New: Generate SQL for JOIN operations
async function generateSqlForJoin(tables, selectedColumns) {
  // Filter schema to only relevant tables
  const relevantSchema = TABLE_MAPPINGS.filter(t => tables.includes(t.name));
  
  if (relevantSchema.length < 2) {
      throw new Error("Need at least 2 tables to join");
  }

  const schemaContext = relevantSchema.map(t => 
      `Table ${t.name} (Real Name: ${t.tableName}, DB: ${t.dbType}): Columns [${t.columns.join(', ')}]`
  ).join('\n');

  // Logic to handle cross-database joins is complex. 
  // For this demo, we will assume tables are in the SAME DB or we generate a standard SQL 
  // and the executor decides how to run it (or fails if cross-db).
  // Assuming they are in the same DB (e.g. Postgres) for the generated SQL to be valid directly.
  
  const systemInstruction = `
    You are an expert SQL Generator.
    Task: Write a standard SQL SELECT statement to join the following tables.
    
    Schema:
    ${schemaContext}
    
    User Selected Columns:
    ${selectedColumns.join(', ')}
    
    Rules:
    1. Determine the best JOIN keys based on column names (e.g. 'owner' = 'owner' or 'id' = 'project_id').
    2. Use LEFT JOIN by default to preserve data from the first table.
    3. Select ONLY the columns specified in 'User Selected Columns'. Alias them if needed to avoid ambiguity (e.g. t1.col AS t1_col).
    4. Output ONLY the raw SQL string, no markdown.
  `;

  try {
     const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Join these tables: ${tables.join(', ')}`,
        config: {
            systemInstruction: systemInstruction,
            // We want raw text (SQL)
        }
     });
     return response.text.replace(/```sql/g, '').replace(/```/g, '').trim();
  } catch (e) {
      console.error("SQL Gen Error:", e);
      return null;
  }
}

module.exports = { identifyRelevantTables, generateSqlForJoin };
