
require('dotenv').config();

// 定義資料庫連線設定 (與前端模擬資料一致，但用於真實連線)
const DB_CONFIG = {
  oracle: {
    user: process.env.ORACLE_USER || "scott",
    password: process.env.ORACLE_PASSWORD || "tiger",
    connectString: process.env.ORACLE_CONN || "localhost:1521/orclpdb1"
  },
  postgres: {
    user: process.env.PG_USER || 'myuser',
    host: process.env.PG_HOST || 'localhost',
    database: process.env.PG_DB || 'mydb',
    password: process.env.PG_PASSWORD || 'mypassword',
    port: parseInt(process.env.PG_PORT || '5432')
  }
};

// 定義資料表 Schema 映射 (真實環境中通常會讀取資料庫 metadata，這裡為示範維持靜態定義)
const TABLE_MAPPINGS = [
  {
    name: 'mytest1',
    description: '這是一個測試資料表',
    columns: ['id', 'test_name', 'test_value', 'created_at', 'memo'],
    dbType: 'oracle',
    tableName: 'MYTEST1', // 真實 DB 中的 Table Name
    requiresWhere: false
  },
  {
    name: 'project_1',
    description: '這是記錄個人專案表',
    columns: ['project_id', 'project_name', 'owner', 'start_date', 'status', 'budget'],
    dbType: 'postgres',
    tableName: 'project_1',
    requiresWhere: false
  },
  {
    name: 'employees',
    description: '公司員工基本資料表',
    columns: ['emp_id', 'emp_name', 'dept_id', 'title', 'hire_date', 'salary', 'email'],
    dbType: 'oracle',
    tableName: 'EMPLOYEES',
    requiresWhere: false
  },
  {
    name: 'sales_orders',
    description: '產品銷售訂單紀錄',
    columns: ['order_id', 'customer_name', 'product_name', 'amount', 'order_date', 'region', 'sales_rep'],
    dbType: 'postgres',
    tableName: 'sales_orders',
    requiresWhere: true
  },
  {
    name: 'inventory_items',
    description: '倉庫庫存商品清單',
    columns: ['sku', 'product_name', 'category', 'quantity_on_hand', 'warehouse_loc', 'last_restock_date'],
    dbType: 'postgres',
    tableName: 'inventory_items',
    requiresWhere: false
  },
  {
    name: 'customer_support',
    description: '客戶服務工單紀錄',
    columns: ['ticket_id', 'customer_email', 'issue_type', 'priority', 'status', 'created_at', 'assigned_emp_id'],
    dbType: 'oracle',
    tableName: 'CUSTOMER_SUPPORT',
    requiresWhere: false
  }
];

module.exports = { DB_CONFIG, TABLE_MAPPINGS };
