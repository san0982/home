
const express = require('express');
const cors = require('cors');
const { identifyRelevantTables, generateSqlForJoin } = require('./gemini');
const { queryTable, executeRawQuery } = require('./db');
const { TABLE_MAPPINGS } = require('./config');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Helper: Build SQL from explicit conditions
function buildSqlFromConditions(tables, columns, conditions) {
    if (!conditions || conditions.length === 0) return null;

    // Start with the first table
    // columns example: ["mytest1.id", "project_1.project_name"]
    // We need to ensure aliases or full names are correct.
    const selectClause = columns.join(', ');
    
    let sql = `SELECT ${selectClause} FROM ${tables[0]}`;
    
    // Track joined tables to avoid duplicates or invalid references (simple set)
    const joinedTables = new Set([tables[0]]);
    
    // We assume the user creates a valid chain or star. 
    // We simply iterate remaining tables and find a condition that connects them to the graph.
    const remainingTables = tables.slice(1);
    
    remainingTables.forEach(targetTable => {
        // Find a condition where:
        // (Left == Target AND Right is in Joined) OR (Right == Target AND Left is in Joined)
        const condition = conditions.find(c => 
            (c.leftTable === targetTable && joinedTables.has(c.rightTable)) ||
            (c.rightTable === targetTable && joinedTables.has(c.leftTable))
        );
        
        if (condition) {
            const isLeftTarget = condition.leftTable === targetTable;
            const targetCol = isLeftTarget ? condition.leftColumn : condition.rightColumn;
            const sourceTable = isLeftTarget ? condition.rightTable : condition.leftTable;
            const sourceCol = isLeftTarget ? condition.rightColumn : condition.leftColumn;
            
            sql += ` LEFT JOIN ${targetTable} ON ${targetTable}.${targetCol} = ${sourceTable}.${sourceCol}`;
            joinedTables.add(targetTable);
        } else {
             // Fallback: If no condition found yet, might be a disjoint table or order issue.
             // For this simple builder, we just append it with a dummy join or cross join.
             // But to be safe for SQL, let's use LEFT JOIN ON 1=1 (Cross Join effectively)
             sql += ` LEFT JOIN ${targetTable} ON 1=1`; 
             joinedTables.add(targetTable);
        }
    });
    
    return sql;
}

// 1. 分析使用者查詢
app.post('/api/analyze', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query) return res.status(400).json({ error: 'Query required' });
    
    const tables = await identifyRelevantTables(query);
    res.json({ tables });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Analysis failed' });
  }
});

// 2. 取得資料預覽
app.post('/api/preview', async (req, res) => {
  try {
    const { tableName } = req.body;
    if (!tableName) return res.status(400).json({ error: 'Table name required' });

    const { rows, sql } = await queryTable(tableName, 10); // Limit 10
    res.json({ data: rows, sql });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Database query failed' });
  }
});

// 3. Join 查詢
app.post('/api/join', async (req, res) => {
  try {
    const { tables, selectedColumns, joinConditions } = req.body;
    if (!tables || tables.length < 2) return res.status(400).json({ error: 'At least 2 tables required' });
    
    let sql = '';
    
    // Priority: Use explicit conditions if available
    if (joinConditions && joinConditions.length > 0) {
        console.log("Building SQL from explicit conditions...");
        sql = buildSqlFromConditions(tables, selectedColumns, joinConditions);
    } 
    
    // Fallback: Use AI if no conditions provided or builder failed
    if (!sql) {
        console.log("Generating SQL via AI...");
        sql = await generateSqlForJoin(tables, selectedColumns);
    }
    
    console.log("Executing SQL:", sql);
    
    if (!sql) return res.status(500).json({ error: 'Failed to generate SQL' });

    const primaryTable = TABLE_MAPPINGS.find(t => t.name === tables[0]);
    const dbType = primaryTable ? primaryTable.dbType : 'postgres';

    const data = await executeRawQuery(sql, dbType);
    res.json({ data: data.slice(0, 10), sql }); // Limit preview
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

// 4. 取得完整資料下載
app.post('/api/download', async (req, res) => {
  try {
    const { tableName } = req.body;
    if (!tableName) return res.status(400).json({ error: 'Table name required' });

    const { rows } = await queryTable(tableName, 1000); // Limit 1000 for download
    res.json({ data: rows });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  console.log(`Ensure you have set API_KEY, ORACLE_*, and PG_* in .env`);
});
