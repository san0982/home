import React from 'react';
import { ChatInterface } from './components/ChatInterface';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-0 md:p-6">
      <div className="w-full h-full md:h-auto">
        <ChatInterface />
      </div>
    </div>
  );
};

export default App;
