
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Database, Check, X, Download, FileSpreadsheet, Loader2, Server, AlertCircle, Terminal, ToggleLeft, ToggleRight, Info, Plus, Table2, ArrowRight, Layers, ArrowLeft, Link2, Trash2 } from 'lucide-react';
import * as XLSX from 'xlsx';
import { ChatMessage, MessageType, ConversationState, JoinCondition } from '../types';
import { identifyRelevantTables, generateFriendlyResponse, getTableColumns } from '../services/geminiService';
import { fetchPreviewData, fetchFullData, fetchJoinData, getTableDetails, getConnectionDetails, DB_SCHEMA } from '../services/mockData';
import { apiClient } from '../services/apiClient';

export const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'ai',
      type: MessageType.TEXT,
      content: "您好！我是您的 DataQuery AI 助手。已為您載入 Oracle 與 PostgreSQL 設定。請問今天想查詢哪個資料表？"
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [state, setState] = useState<ConversationState>('idle');
  
  // Staging area for selected tables
  const [selectedTables, setSelectedTables] = useState<string[]>([]);
  
  // Staging area for selected columns (format: "TableName.ColumnName")
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);

  // Staging area for Join Conditions
  const [joinConditions, setJoinConditions] = useState<JoinCondition[]>([]);

  const [useBackend, setUseBackend] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedTables, state]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || state !== 'idle') return;

    const userText = inputValue;
    setInputValue('');
    setSelectedTables([]); 
    setSelectedColumns([]);
    setJoinConditions([]);
    
    // Add User Message
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      type: MessageType.TEXT,
      content: userText
    };
    setMessages(prev => [...prev, userMsg]);
    setState('analyzing');

    try {
      const ackText = await generateFriendlyResponse(userText);
      
      let tables: string[] = [];
      if (useBackend) {
        try {
            tables = await apiClient.analyzeQuery(userText);
        } catch (e) {
            setMessages(prev => [...prev, {
                id: Date.now().toString(),
                sender: 'ai',
                type: MessageType.ERROR,
                content: "連線後端伺服器失敗 (http://localhost:3001)。請確認後端已啟動。"
            }]);
            setState('idle');
            return;
        }
      } else {
        tables = await identifyRelevantTables(userText);
      }

      if (tables.length === 0) {
         setMessages(prev => [...prev, {
            id: Date.now().toString(),
            sender: 'ai',
            type: MessageType.TEXT,
            content: "抱歉，我無法將您的需求對應到目前設定的資料表。"
         }]);
         setState('idle');
         return;
      }

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        type: MessageType.TABLE_SELECTION,
        content: `我找到了 ${tables.length} 個可能符合您需求的資料表。若您需要進行關聯查詢 (Join)，請手動勾選其他資料表。`,
        suggestedTables: tables
      };
      
      setSelectedTables(tables);
      setMessages(prev => [...prev, aiMsg]);
      setState('selecting_tables');

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        sender: 'ai',
        type: MessageType.ERROR,
        content: "抱歉，分析您的需求時發生錯誤。"
      }]);
      setState('idle');
    }
  };

  const toggleTableSelection = (tableName: string) => {
    if (selectedTables.includes(tableName)) {
        setSelectedTables(prev => prev.filter(t => t !== tableName));
    } else {
        setSelectedTables(prev => [...prev, tableName]);
    }
  };

  const confirmTableSelection = async () => {
      if (selectedTables.length === 0) {
          alert("請至少選擇一個資料表");
          return;
      }

      if (selectedTables.length > 1) {
          // New Step: Configure Joins
           setMessages(prev => [...prev, {
              id: Date.now().toString(),
              sender: 'user',
              type: MessageType.TEXT,
              content: `已選擇 ${selectedTables.length} 個表格：${selectedTables.join(', ')}。`
          }]);
          setState('configuring_joins');
      } else {
          // Single table flow
          handleSingleTablePreview(selectedTables[0]);
      }
  };

  const handleBackToTables = () => {
      // Remove the last user confirmation message to keep chat clean visually, or just append a "back" note?
      // Simpler to just update state.
      setState('selecting_tables');
  };

  const confirmJoinConfig = () => {
      // Proceed to Column Selection
      const columnsInfo = getTableColumns(selectedTables);
      
      setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: 'ai',
          type: MessageType.COLUMN_SELECTION,
          content: "請勾選您希望在結果中顯示的欄位：",
          availableColumns: columnsInfo
      }]);
      
      const allCols = columnsInfo.flatMap(t => t.columns.map(c => `${t.tableName}.${c}`));
      setSelectedColumns(allCols);
      
      setState('selecting_columns');
  };

  const handleBackToJoinConfig = () => {
      setState('configuring_joins');
  };

  const handleSingleTablePreview = async (tableName: string) => {
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      sender: 'user',
      type: MessageType.TEXT,
      content: `確認，請查詢 ${tableName} 資料表。`
    }]);

    setState('fetching_preview');
    try {
      const tableInfo = getTableDetails(tableName);
      let data: any[] = [];
      let sql: string | undefined = undefined;

      if (useBackend) {
         const result = await apiClient.fetchPreview(tableName);
         data = result.data;
         sql = result.sql;
      } else {
         const result = await fetchPreviewData(tableName);
         data = result.data;
         sql = result.sql;
      }
      
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        sender: 'ai',
        type: MessageType.DATA_PREVIEW,
        content: tableInfo?.requiresWhere 
          ? `注意：此資料表 '${tableName}' 設定為必須包含篩選條件。目前顯示前 10 筆範例資料。`
          : `這是 '${tableName}' 的前 10 筆資料。請問內容正確嗎？`,
        previewData: {
          tableName,
          rows: data,
          sql: sql
        }
      }]);
      setState('waiting_preview_confirm');
    } catch (error) {
       handleError("無法取得預覽資料");
    }
  };

  const confirmColumnSelection = async () => {
     setMessages(prev => [...prev, {
         id: Date.now().toString(),
         sender: 'user',
         type: MessageType.TEXT,
         content: `已選擇 ${selectedColumns.length} 個欄位，開始執行查詢。`
     }]);
     
     setState('fetching_preview');
     
     try {
         let data: any[] = [];
         let sql: string | undefined = undefined;

         if (useBackend) {
             const result = await apiClient.fetchJoinPreview(selectedTables, selectedColumns, joinConditions);
             data = result.data;
             sql = result.sql;
         } else {
             const result = await fetchJoinData(selectedTables, selectedColumns, joinConditions);
             data = result.data;
             sql = result.sql;
         }
         
         setMessages(prev => [...prev, {
             id: Date.now().toString(),
             sender: 'ai',
             type: MessageType.DATA_PREVIEW,
             content: "根據您的選擇，這是合併查詢後的前 10 筆結果：",
             previewData: {
                 tableName: "Joined_Result",
                 rows: data,
                 sql: sql
             }
         }]);
         setState('waiting_preview_confirm');
         
     } catch (e) {
         handleError("合併查詢執行失敗");
     }
  };

  const handleError = (msg: string) => {
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        sender: 'ai',
        type: MessageType.ERROR,
        content: msg
      }]);
      setState('idle');
  };

  const handlePreviewConfirm = async (tableName: string) => {
    setMessages(prev => [...prev, {
        id: Date.now().toString(),
        sender: 'user',
        type: MessageType.TEXT,
        content: "看起來沒問題，請下載完整資料。"
    }]);
    
    setState('generating_download');
    
    setTimeout(async () => {
        setMessages(prev => [...prev, {
            id: Date.now().toString(),
            sender: 'ai',
            type: MessageType.DOWNLOAD_ACTION,
            content: "我已經為您準備好完整的資料集了。",
            downloadData: {
                tableName,
                totalRows: useBackend ? 1000 : 50 
            }
        }]);
        setState('idle');
    }, 1000);
  };

  const handleDownload = async (tableName: string) => {
    try {
        let fullData: any[] = [];
        if (selectedTables.length > 1) {
            if (useBackend) {
                const res = await apiClient.fetchJoinPreview(selectedTables, selectedColumns, joinConditions);
                fullData = res.data; // Join query usually re-runs logic or calls specific download endpoint if needed
            } else {
                const res = await fetchJoinData(selectedTables, selectedColumns, joinConditions);
                fullData = res.data;
            }
        } else {
            if (useBackend) {
               fullData = await apiClient.fetchFullData(tableName);
            } else {
               fullData = await fetchFullData(tableName);
            }
        }

        const ws = XLSX.utils.json_to_sheet(fullData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
        XLSX.writeFile(wb, `DataQuery_Export_${new Date().getTime()}.xlsx`);
    } catch (e) {
        alert("下載檔案時發生錯誤");
    }
  };

  const handleCancel = () => {
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        sender: 'user',
        type: MessageType.TEXT,
        content: "取消目前操作。"
      }, {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        type: MessageType.TEXT,
        content: "好的，已重置。請告訴我您其他的需求。"
      }]);
      setState('idle');
      setSelectedTables([]);
      setSelectedColumns([]);
      setJoinConditions([]);
  };

  // --- Components ---

  const TableCard = ({ tableName, selected, onClick, isRecommended }: { tableName: string, selected: boolean, onClick: () => void, isRecommended?: boolean }) => {
     const details = getTableDetails(tableName);
     if (!details) return null;
     const conn = getConnectionDetails(details.connectionId);

     return (
       <div 
         onClick={onClick}
         className={`border rounded-lg p-3 transition-all cursor-pointer group relative flex flex-col justify-between ${
             selected 
              ? 'bg-indigo-50 border-indigo-300 ring-1 ring-indigo-300' 
              : 'bg-slate-50 border-slate-200 hover:bg-white hover:shadow-md'
         }`}
       >
          <div>
            <div className="flex justify-between items-start mb-1">
                <div className="flex items-center gap-2">
                <div className={`p-1 rounded ${selected ? 'bg-indigo-500 text-white' : 'bg-slate-200 text-slate-500'}`}>
                    <Table2 className="w-3.5 h-3.5" />
                </div>
                <span className={`font-semibold ${selected ? 'text-indigo-900' : 'text-slate-800'}`}>{details.name}</span>
                </div>
                <div className="flex items-center gap-1">
                    {isRecommended && <span className="text-[10px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full font-medium">推薦</span>}
                    {selected && <Check className="w-4 h-4 text-indigo-600" />}
                </div>
            </div>
            <p className="text-xs text-slate-500 mb-2 line-clamp-2">{details.description}</p>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-200/50 flex flex-col gap-1">
             <div className="flex items-center gap-1.5">
               <Server className="w-3 h-3 text-slate-400" />
               <span className="text-[10px] text-slate-600 font-bold">{conn?.name || '未知連線'}</span>
             </div>
          </div>
       </div>
     );
  };

  const getAllTables = (suggested: string[]) => {
      // 1. Identify connections from suggested tables
      const suggestedSchemas = DB_SCHEMA.filter(t => suggested.includes(t.name));
      const activeConnIds = new Set(suggestedSchemas.map(t => t.connectionId));

      // 2. Get all other tables
      let otherSchemas = DB_SCHEMA.filter(t => !suggested.includes(t.name));

      // 3. Sort: Tables with same connection ID as suggested ones go to top
      if (activeConnIds.size > 0) {
          otherSchemas.sort((a, b) => {
              const aSame = activeConnIds.has(a.connectionId) ? 1 : 0;
              const bSame = activeConnIds.has(b.connectionId) ? 1 : 0;
              return bSame - aSame; // Descending
          });
      }

      // 4. Map to names and slice top 6
      const otherTables = otherSchemas.map(t => t.name).slice(0, 6);
      
      return { suggested, otherTables };
  };

  // --- Join Configuration Step Component ---
  const JoinConfigStep = ({ tables, onConfirm, onBack }: { tables: string[], onConfirm: () => void, onBack: () => void }) => {
      const [leftTable, setLeftTable] = useState(tables[0]);
      const [rightTable, setRightTable] = useState(tables.length > 1 ? tables[1] : tables[0]);
      const [leftCol, setLeftCol] = useState('');
      const [rightCol, setRightCol] = useState('');

      const columnsInfo = getTableColumns(tables);
      const leftColumns = columnsInfo.find(t => t.tableName === leftTable)?.columns || [];
      const rightColumns = columnsInfo.find(t => t.tableName === rightTable)?.columns || [];

      // Auto-select first columns if available
      useEffect(() => {
          if (leftColumns.length > 0 && !leftCol) setLeftCol(leftColumns[0]);
          if (rightColumns.length > 0 && !rightCol) setRightCol(rightColumns[0]);
      }, [leftTable, rightTable, leftColumns, rightColumns]);

      const addCondition = () => {
          if (!leftTable || !rightTable || !leftCol || !rightCol) return;
          const newCond: JoinCondition = { leftTable, leftColumn: leftCol, rightTable, rightColumn: rightCol };
          setJoinConditions(prev => [...prev, newCond]);
      };

      const removeCondition = (idx: number) => {
          setJoinConditions(prev => prev.filter((_, i) => i !== idx));
      };

      return (
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm w-full animate-in fade-in slide-in-from-bottom-2 duration-300">
              <div className="flex justify-between items-center mb-3">
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                      <Link2 className="w-3.5 h-3.5" /> 設定關聯條件 (Join Keys)
                  </p>
                  <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">已設定: {joinConditions.length}</span>
              </div>

              {/* Input Row */}
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 mb-3 flex flex-wrap gap-2 items-end">
                  <div className="flex flex-col gap-1 flex-1 min-w-[120px]">
                      <label className="text-[10px] text-slate-500 font-bold">表格 A</label>
                      <select value={leftTable} onChange={e => { setLeftTable(e.target.value); setLeftCol(''); }} className="text-xs border border-slate-300 rounded p-1.5 bg-white">
                          {tables.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                  </div>
                  <div className="flex flex-col gap-1 flex-1 min-w-[120px]">
                      <label className="text-[10px] text-slate-500 font-bold">欄位 A</label>
                      <select value={leftCol} onChange={e => setLeftCol(e.target.value)} className="text-xs border border-slate-300 rounded p-1.5 bg-white">
                          {leftColumns.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                  </div>
                  
                  <div className="pb-2 text-slate-400 font-bold">=</div>
                  
                  <div className="flex flex-col gap-1 flex-1 min-w-[120px]">
                      <label className="text-[10px] text-slate-500 font-bold">表格 B</label>
                      <select value={rightTable} onChange={e => { setRightTable(e.target.value); setRightCol(''); }} className="text-xs border border-slate-300 rounded p-1.5 bg-white">
                          {tables.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                  </div>
                   <div className="flex flex-col gap-1 flex-1 min-w-[120px]">
                      <label className="text-[10px] text-slate-500 font-bold">欄位 B</label>
                      <select value={rightCol} onChange={e => setRightCol(e.target.value)} className="text-xs border border-slate-300 rounded p-1.5 bg-white">
                          {rightColumns.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                  </div>
                  <button onClick={addCondition} className="mb-[1px] p-1.5 bg-indigo-600 text-white rounded hover:bg-indigo-700">
                      <Plus className="w-4 h-4" />
                  </button>
              </div>

              {/* Condition List */}
              {joinConditions.length > 0 ? (
                  <div className="space-y-2 mb-4">
                      {joinConditions.map((cond, idx) => (
                          <div key={idx} className="flex items-center justify-between p-2 bg-indigo-50 border border-indigo-100 rounded text-xs text-indigo-900">
                              <span className="font-mono">
                                  <b>{cond.leftTable}</b>.{cond.leftColumn} <span className="text-slate-400 mx-1">=</span> <b>{cond.rightTable}</b>.{cond.rightColumn}
                              </span>
                              <button onClick={() => removeCondition(idx)} className="text-red-400 hover:text-red-600">
                                  <X className="w-3.5 h-3.5" />
                              </button>
                          </div>
                      ))}
                  </div>
              ) : (
                  <p className="text-xs text-slate-400 mb-4 text-center italic">尚未新增條件。若未設定，系統將嘗試自動判斷或使用 Cross Join。</p>
              )}

              <div className="flex gap-2 justify-end border-t border-slate-100 pt-3">
                   <button onClick={onBack} className="flex items-center gap-1 px-3 py-1.5 text-slate-500 text-xs hover:bg-slate-100 rounded">
                        <ArrowLeft className="w-3 h-3"/> 上一步
                   </button>
                   <button 
                     onClick={onConfirm}
                     className="flex items-center gap-2 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs rounded-lg transition-colors"
                   >
                     下一步：選擇欄位 <ArrowRight className="w-3 h-3" />
                   </button>
              </div>
          </div>
      );
  };

  return (
    <div className="flex flex-col h-full bg-white max-w-5xl mx-auto shadow-2xl overflow-hidden rounded-none md:rounded-2xl md:my-4 md:h-[95vh] border border-slate-200">
      
      {/* Header */}
      <div className="bg-slate-900 text-white p-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500 rounded-lg">
               <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-lg">DataQuery AI 智慧查詢</h1>
              <p className="text-xs text-slate-300">支援跨資料庫關聯查詢 (Oracle, PostgreSQL)</p>
            </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-full border border-slate-700">
           <span className={`text-xs font-medium ${!useBackend ? 'text-emerald-400' : 'text-slate-400'}`}>模擬</span>
           <button onClick={() => setUseBackend(!useBackend)} className="focus:outline-none">
              {useBackend ? <ToggleRight className="w-8 h-8 text-indigo-400" /> : <ToggleLeft className="w-8 h-8 text-emerald-500" />}
           </button>
           <span className={`text-xs font-medium ${useBackend ? 'text-indigo-400' : 'text-slate-400'}`}>後端</span>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-slate-50">
        
        {useBackend && (
          <div className="bg-indigo-50 border border-indigo-100 p-3 rounded-xl flex items-start gap-3 text-xs text-indigo-800">
             <Info className="w-4 h-4 mt-0.5 shrink-0" />
             <div><strong>真實後端模式</strong>: 需啟動本地伺服器 (Port 3001)。AI 將自動產生 SQL Join 語法。</div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex max-w-[95%] md:max-w-[85%] gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-1 ${msg.sender === 'user' ? 'bg-indigo-600' : 'bg-emerald-600'}`}>
                {msg.sender === 'user' ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
              </div>

              <div className={`flex flex-col gap-2 w-full ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                <div className={`p-3 rounded-2xl text-sm leading-relaxed shadow-sm ${
                  msg.sender === 'user' 
                    ? 'bg-indigo-600 text-white rounded-tr-none' 
                    : 'bg-white text-slate-700 border border-slate-200 rounded-tl-none'
                }`}>
                  {msg.content}
                </div>

                {/* --- Step 1: Table Selection --- */}
                {msg.type === MessageType.TABLE_SELECTION && msg.suggestedTables && state === 'selecting_tables' && messages[messages.length-1].id === msg.id && (
                  <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm w-full animate-in fade-in slide-in-from-bottom-2 duration-300">
                    <div className="flex justify-between items-center mb-3">
                         <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">選擇要查詢的資料表 (可多選 Join)</p>
                         <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">已選: {selectedTables.length}</span>
                    </div>

                    {(() => {
                        const { suggested, otherTables } = getAllTables(msg.suggestedTables || []);
                        return (
                            <>
                                {suggested.length > 0 && (
                                    <div className="mb-4">
                                        <p className="text-xs text-emerald-600 font-bold mb-2 flex items-center gap-1"><Bot className="w-3 h-3"/> AI 推薦項目</p>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                            {suggested.map(t => (
                                                <TableCard 
                                                    key={t} 
                                                    tableName={t} 
                                                    selected={selectedTables.includes(t)} 
                                                    onClick={() => toggleTableSelection(t)}
                                                    isRecommended={true}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                )}
                                
                                {otherTables.length > 0 && (
                                    <div className="mb-4">
                                        <p className="text-xs text-slate-400 font-bold mb-2 flex items-center gap-1"><Database className="w-3 h-3"/> 其他可用資料表</p>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                            {otherTables.map(t => (
                                                <TableCard 
                                                    key={t} 
                                                    tableName={t} 
                                                    selected={selectedTables.includes(t)} 
                                                    onClick={() => toggleTableSelection(t)}
                                                    isRecommended={false}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </>
                        );
                    })()}

                    <div className="flex gap-2 justify-end border-t border-slate-100 pt-3">
                       <button onClick={handleCancel} className="px-3 py-1.5 text-slate-500 text-xs hover:bg-slate-100 rounded">取消</button>
                       <button 
                         onClick={confirmTableSelection}
                         disabled={selectedTables.length === 0}
                         className="flex items-center gap-2 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs rounded-lg transition-colors"
                       >
                         {selectedTables.length > 1 ? "下一步：設定 Join 條件" : "下一步：預覽資料"} <ArrowRight className="w-3 h-3" />
                       </button>
                    </div>
                  </div>
                )}

                {/* --- Step 2: Join Configuration (New) --- */}
                {state === 'configuring_joins' && msg.id === messages[messages.length-1].id && (
                    <JoinConfigStep 
                        tables={selectedTables} 
                        onConfirm={confirmJoinConfig} 
                        onBack={handleBackToTables}
                    />
                )}

                {/* --- Step 3: Column Selection --- */}
                {msg.type === MessageType.COLUMN_SELECTION && msg.availableColumns && state === 'selecting_columns' && messages[messages.length-1].id === msg.id && (
                    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm w-full animate-in fade-in slide-in-from-bottom-2 duration-300">
                         <div className="mb-4 space-y-4 max-h-[300px] overflow-y-auto pr-2">
                             {msg.availableColumns.map((tbl) => (
                                 <div key={tbl.tableName} className="border border-slate-100 rounded-lg overflow-hidden">
                                     <div className="bg-slate-50 px-3 py-2 border-b border-slate-100 flex items-center gap-2">
                                         <Database className="w-3 h-3 text-slate-400" />
                                         <span className="text-xs font-bold text-slate-700">{tbl.tableName}</span>
                                     </div>
                                     <div className="p-2 grid grid-cols-2 gap-2">
                                         {tbl.columns.map(col => {
                                             const colKey = `${tbl.tableName}.${col}`;
                                             const isChecked = selectedColumns.includes(colKey);
                                             return (
                                                 <label key={colKey} className={`flex items-center gap-2 p-1.5 rounded cursor-pointer border transition-all ${isChecked ? 'bg-indigo-50 border-indigo-200' : 'border-transparent hover:bg-slate-50'}`}>
                                                     <input 
                                                         type="checkbox" 
                                                         className="w-3.5 h-3.5 accent-indigo-600 rounded border-slate-300"
                                                         checked={isChecked}
                                                         onChange={() => {
                                                             if (isChecked) setSelectedColumns(prev => prev.filter(c => c !== colKey));
                                                             else setSelectedColumns(prev => [...prev, colKey]);
                                                         }}
                                                     />
                                                     <span className="text-xs text-slate-600">{col}</span>
                                                 </label>
                                             );
                                         })}
                                     </div>
                                 </div>
                             ))}
                         </div>
                         <div className="flex gap-2 justify-end border-t border-slate-100 pt-3">
                             <button onClick={handleBackToJoinConfig} className="flex items-center gap-1 px-3 py-1.5 text-slate-500 text-xs hover:bg-slate-100 rounded mr-auto">
                                <ArrowLeft className="w-3 h-3"/> 上一步
                             </button>
                             <button onClick={() => setSelectedColumns([])} className="px-3 py-1.5 text-slate-400 text-xs hover:text-slate-600">全部取消</button>
                             <button onClick={() => {
                                 const all = msg.availableColumns?.flatMap(t => t.columns.map(c => `${t.tableName}.${c}`)) || [];
                                 setSelectedColumns(all);
                             }} className="px-3 py-1.5 text-indigo-600 text-xs hover:bg-indigo-50 rounded">全選</button>
                             <div className="border-l border-slate-200 mx-1"></div>
                             <button 
                               onClick={confirmColumnSelection}
                               className="flex items-center gap-2 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs rounded-lg transition-colors"
                             >
                               <Layers className="w-3 h-3" /> 執行合併查詢
                             </button>
                         </div>
                    </div>
                )}

                {/* --- Step 4: Data Preview --- */}
                {msg.type === MessageType.DATA_PREVIEW && msg.previewData && state === 'waiting_preview_confirm' && messages[messages.length-1].id === msg.id && (
                   <div className="bg-white border border-slate-200 rounded-xl p-0 shadow-sm w-full overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-300">
                      
                      {/* SQL Preview Section (New) */}
                      {msg.previewData.sql && (
                          <div className="bg-slate-900 text-slate-300 p-3 text-[10px] font-mono border-b border-slate-700 relative group">
                              <div className="flex items-center gap-2 mb-2 text-slate-500 uppercase tracking-wider font-bold text-[9px]">
                                  <Terminal className="w-3 h-3" /> Generated SQL
                              </div>
                              <pre className="whitespace-pre-wrap overflow-x-auto custom-scrollbar text-emerald-400">
                                  {msg.previewData.sql}
                              </pre>
                          </div>
                      )}

                      <div className="bg-slate-50 border-b border-slate-200 p-3 flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-2">
                           <Table2 className="w-3 h-3" /> 預覽結果: {msg.previewData.tableName}
                        </span>
                      </div>
                      <div className="overflow-x-auto max-h-[300px]">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100 sticky top-0">
                            <tr>
                              {msg.previewData.rows.length > 0 && Object.keys(msg.previewData.rows[0]).map((key) => (
                                <th key={key} className="px-4 py-2 whitespace-nowrap bg-slate-50">{key}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {msg.previewData.rows.map((row, idx) => (
                              <tr key={idx} className="hover:bg-slate-50 transition-colors">
                                {Object.values(row).map((val: any, vIdx) => (
                                  <td key={vIdx} className="px-4 py-2 whitespace-nowrap text-slate-600 max-w-[150px] truncate">
                                    {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div className="p-3 bg-slate-50 border-t border-slate-200 flex gap-2 justify-end">
                         <button onClick={handleCancel} className="px-4 py-2 text-slate-600 text-sm hover:text-slate-800">取消/重選</button>
                         <button onClick={() => handlePreviewConfirm(msg.previewData!.tableName)} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm rounded-lg shadow-sm transition-colors">
                           <Check className="w-4 h-4" /> 確認無誤，下載檔案
                         </button>
                      </div>
                   </div>
                )}

                {/* --- Download Action --- */}
                {msg.type === MessageType.DOWNLOAD_ACTION && msg.downloadData && (
                  <div className="mt-2">
                    <button onClick={() => handleDownload(msg.downloadData!.tableName)} className="flex items-center gap-3 px-5 py-3 bg-white border border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50 text-emerald-800 rounded-xl shadow-sm transition-all group w-full sm:w-auto">
                      <div className="p-2 bg-emerald-100 rounded-lg group-hover:bg-emerald-200 transition-colors"><FileSpreadsheet className="w-6 h-6 text-emerald-600" /></div>
                      <div className="text-left">
                        <div className="font-semibold text-sm">下載 Excel 報表</div>
                        <div className="text-xs text-emerald-600/70">{msg.downloadData.tableName}.xlsx • 約 {msg.downloadData.totalRows} 筆資料</div>
                      </div>
                      <Download className="w-4 h-4 ml-2" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        
        {/* Loading */}
        {(state === 'analyzing' || state === 'fetching_preview' || state === 'generating_download') && (
           <div className="flex justify-start">
             <div className="flex gap-3 max-w-[75%] items-start">
                <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center mt-1"><Bot className="w-5 h-5 text-white" /></div>
                <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-200 shadow-sm flex items-center gap-3">
                   <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                   <span className="text-sm text-slate-500">
                      {state === 'analyzing' && '正在分析資料庫架構與連線設定...'}
                      {state === 'fetching_preview' && '正在查詢並整合資料...'}
                      {state === 'generating_download' && '正在產生匯出檔案...'}
                   </span>
                </div>
             </div>
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t border-slate-200 shrink-0">
         
         {/* Staging Area for Selected Tables (Chips) */}
         {selectedTables.length > 0 && state === 'selecting_tables' && (
             <div className="flex flex-wrap gap-2 mb-3 animate-in fade-in slide-in-from-bottom-1">
                 {selectedTables.map(t => (
                     <span key={t} className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs rounded-full font-medium shadow-sm">
                         <Table2 className="w-3 h-3" /> {t}
                         <button onClick={() => toggleTableSelection(t)} className="hover:bg-indigo-200 rounded-full p-0.5"><X className="w-3 h-3" /></button>
                     </span>
                 ))}
                 <button 
                   onClick={confirmTableSelection}
                   className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white text-xs rounded-full font-medium transition-colors"
                 >
                   <Check className="w-3 h-3" /> 完成選擇 ({selectedTables.length})
                 </button>
             </div>
         )}

         <div className="relative">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              disabled={state !== 'idle'}
              placeholder={state === 'idle' ? "輸入查詢需求 (例如: 整合我的測試表與專案表)..." : "請先完成上方的互動..."}
              className="w-full pl-4 pr-12 py-4 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-inner text-sm"
            />
            <button onClick={handleSendMessage} disabled={!inputValue.trim() || state !== 'idle'} className="absolute right-2 top-2 bottom-2 p-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white rounded-lg transition-colors flex items-center justify-center aspect-square">
              <Send className="w-5 h-5" />
            </button>
         </div>
      </div>
    </div>
  );
};
